@echo off
chcp 65001 >nul
title GitHub Sync - Pull
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0lib\Pull.ps1"
