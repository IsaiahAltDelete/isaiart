﻿# Pull - update every local repository from its remote
trap {
  Write-Host ''
  Write-Host ('  Unexpected error: ' + $_.Exception.Message) -ForegroundColor Red
  Write-Host '  Press Enter to close this window. ' -ForegroundColor DarkGray -NoNewline
  [void](Read-Host)
  exit 1
}

. (Join-Path $PSScriptRoot 'common.ps1')

Load-Config
$script:LogFile = Join-Path $script:RepoDir 'pull.log'

Clear-Host
Heading 'GitHub Sync  ·  Pull' 'Update every local repository with the latest changes from GitHub'

if (-not (Test-Tool 'git')) {
  Write-Host '  Git is not available. Run Install.cmd again.' -ForegroundColor Red
  PauseExit 1
}

Find-Repos
if ($script:Repos.Count -eq 0) {
  Show-NoReposNotice
  WriteLog "pull: no repositories in $($script:RepoDir)"
  PauseExit 1
}

Field 'Folder'       $script:RepoDir
Field 'Account'      $script:GhOwner
Field 'Repositories' $script:Repos.Count
Section 'Updating'

WriteLog '── pull started ──'
$updated = 0; $current = 0; $failed = 0
$total = $script:Repos.Count; $idx = 0

foreach ($repo in $script:Repos) {
  $idx++
  $name = $repo.Name
  Row $idx $total $name
  Working 'working'

  $r = Invoke-Git -Dir $repo.FullName -Arguments @('pull','--ff-only')
  $retried = ''
  if ($r.Code -ne 0 -and $r.Output -match '(?i)local changes|would be overwritten|not possible to fast-forward|divergent|need to specify how to reconcile') {
    $retried = ' (local changes set aside)'
    $r = Invoke-Git -Dir $repo.FullName -Arguments @('pull','--rebase','--autostash')
  }

  ClearWorking
  Row $idx $total $name

  if ($r.Code -ne 0 -and $r.Output -match "(?i)no such ref was fetched|couldn't find remote ref") {
    # A repository that exists on GitHub but has no commits yet.
    $current++
    Neutral 'empty repository'
    WriteLog "OK    $name  empty repository"
  }
  elseif ($r.Code -ne 0) {
    $failed++
    Failed_ 'failed'
    Detail $r.Output
    WriteLog "FAIL  $name  rc=$($r.Code)  $(Flat $r.Output)"
  }
  elseif ($r.Output -match '(?i)already up[- ]to[- ]date') {
    $current++
    Neutral 'up to date'
    WriteLog "OK    $name  already up to date"
  }
  else {
    $updated++
    $changed = @($r.Output -split "`n" | Where-Object { $_ -match '^\s.*\|' }).Count
    if ($changed -gt 0) { Ok "updated ($changed file(s))$retried" } else { Ok "updated$retried" }
    WriteLog "OK    $name  updated"
  }
}

Write-Host ''
Rule
Write-Host '  Summary' -ForegroundColor White -NoNewline
Write-Host '     ' -NoNewline
Write-Host "$updated updated" -ForegroundColor Green -NoNewline
Write-Host '   ·   ' -ForegroundColor DarkGray -NoNewline
Write-Host "$current already current" -ForegroundColor DarkGray -NoNewline
Write-Host '   ·   ' -ForegroundColor DarkGray -NoNewline
Write-Host "$failed failed" -ForegroundColor $(if ($failed -gt 0) { 'Red' } else { 'DarkGray' })
Write-Host '  Log' -ForegroundColor White -NoNewline
Write-Host '         ' -NoNewline
Write-Host $script:LogFile -ForegroundColor DarkGray
Rule

if ($failed -gt 0) {
  Write-Host ''
  Write-Host '  Some repositories could not be updated. See the log for details.' -ForegroundColor Yellow
}
WriteLog "── pull finished: $updated updated, $current current, $failed failed ──"
PauseExit 0
