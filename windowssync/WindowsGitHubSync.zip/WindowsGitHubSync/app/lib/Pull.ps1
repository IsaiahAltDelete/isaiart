﻿# Pull - update every local repository from its remote
trap {
  Write-Host ''
  Write-Host ('  × Unexpected error: ' + $_.Exception.Message) -ForegroundColor Red
  Write-Host '  ↵  press enter to close ' -ForegroundColor DarkGray -NoNewline
  [void](Read-Host)
  exit 1
}

. (Join-Path $PSScriptRoot 'common.ps1')

Set-Theme 'pull'
Load-Config
$script:LogFile = Join-Path $script:RepoDir 'pull.log'

Clear-Host
Banner 'PULL' 'Update every local repository with the latest changes from GitHub'
Write-Host ''
Boot @('Initializing downlink array', 'Scanning local repositories', 'Handshaking with GitHub')

if (-not (Test-Tool 'git')) {
  Write-Host ''
  BoxTop 'MISSING TOOL'
  BoxRow @( ,@('Git is not available. Run Install.cmd again.', 'Red') )
  BoxBot
  PauseExit 1
}

Find-Repos
if ($script:Repos.Count -eq 0) {
  Show-NoReposNotice
  WriteLog "pull: no repositories in $($script:RepoDir)"
  PauseExit 1
}

Write-Host ''
BoxTop 'SOURCE'
Kv 'Folder'       $script:RepoDir
Kv 'Account'      $script:GhOwner
Kv 'Repositories' ([string]$script:Repos.Count)
BoxBot
Section 'UPDATING'

WriteLog '── pull started ──'
$updated = 0; $current = 0; $conflicts = 0; $failed = 0
$total = $script:Repos.Count; $idx = 0

foreach ($repo in $script:Repos) {
  $idx++
  $name = $repo.Name
  $dir  = $repo.FullName
  Row $idx $total $name

  $branch = (Invoke-Git -Dir $dir -Arguments @('rev-parse','--abbrev-ref','HEAD')).Output
  if (-not $branch -or $branch -eq 'HEAD') {
    # Either detached, or a clone of a repository with no commits yet.
    if ((Invoke-Git -Dir $dir -Arguments @('rev-parse','--verify','HEAD')).Code -ne 0) {
      $current++; Neutral 'empty repository'
      WriteLog "OK    $name  empty repository"
    } else {
      $failed++; Failed_ 'skipped — not on a branch'
      Detail 'detached HEAD: check out a branch in this repo, then pull again'
      WriteLog "SKIP  $name  detached HEAD"
    }
    continue
  }
  if (-not (Test-Upstream $dir)) {
    if ((Invoke-Git -Dir $dir -Arguments @('rev-parse','--verify','HEAD')).Code -ne 0) {
      $current++; Neutral 'empty repository'
      WriteLog "OK    $name  empty repository"
    } else {
      $current++; Neutral "local-only branch ($branch) — nothing to pull"
      WriteLog "OK    $name  no upstream for $branch"
    }
    continue
  }

  # Always rebase rather than --ff-only. When this PC has commits AND
  # GitHub moved on (another machine, a cloud agent, a merged PR),
  # --ff-only refuses and the repo stays stuck until someone fixes it
  # by hand. Rebase replays the local commits on top; --autostash
  # carries uncommitted edits across so they never block the pull.
  $before = (Invoke-Git -Dir $dir -Arguments @('rev-parse','HEAD')).Output
  $s = Sync-Remote $dir
  $out = $script:SyncOut

  if ($s -eq 1) {
    $conflicts++; Warned 'conflict — needs a manual merge'
    Detail "your commits and GitHub's touch the same lines; rolled back, nothing lost"
    WriteLog "CONF  $name  rebase conflict, aborted: $(Flat $out)"
    continue
  }
  if ($s -eq 2) {
    if ($out -match "(?i)no such ref was fetched|couldn't find remote ref") {
      $current++; Neutral 'empty repository'
      WriteLog "OK    $name  empty repository"
    } else {
      $failed++; Failed_ 'failed'; Detail $out
      WriteLog "FAIL  $name  $(Flat $out)"
    }
    continue
  }

  $after = (Invoke-Git -Dir $dir -Arguments @('rev-parse','HEAD')).Output
  $ahead = 0
  [void][int]::TryParse((Invoke-Git -Dir $dir -Arguments @('rev-list','--count','@{u}..HEAD')).Output, [ref]$ahead)
  $note = ''
  if ($out -match '(?i)created autostash') { $note += ' · local edits kept' }
  if ($ahead -gt 0) { $note += " · $ahead local commit$(if ($ahead -ne 1) { 's' }) to push" }

  if ($s -eq 3) {
    $updated++; Warned 'updated, but your uncommitted edits clashed'
    Detail "they are safe in 'git stash' — run 'git stash pop' in this repo to get them back"
    WriteLog "WARN  $name  autostash conflict"
  }
  elseif ($before -eq $after -or $out -match '(?i)up[- ]to[- ]date') {
    $current++; Neutral "up to date$note"
    WriteLog "OK    $name  already up to date"
  }
  else {
    $updated++
    $changed = @((Invoke-Git -Dir $dir -Arguments @('diff','--name-only',$before,$after)).Output -split "`n" |
                 Where-Object { $_.Trim().Length -gt 0 }).Count
    Ok "updated · $changed file$(if ($changed -ne 1) { 's' })$note"
    WriteLog "OK    $name  updated ($changed files)"
  }
}

Report @( @('updated', $updated, 'Green'), @('already current', $current, 'DarkGray'),
          @('conflicts', $conflicts, 'Yellow'), @('failed', $failed, 'Red') )

if ($conflicts -gt 0) {
  Write-Host ''
  Write-Host '  ▲ Conflicted repos were rolled back untouched. Merge them by hand.' -ForegroundColor Yellow
}
if ($failed -gt 0) {
  Write-Host ''
  Write-Host '  × Some repositories could not be updated. The log has the full Git output.' -ForegroundColor Red
}
WriteLog "── pull finished: $updated updated, $current current, $conflicts conflicts, $failed failed ──"
PauseExit 0
