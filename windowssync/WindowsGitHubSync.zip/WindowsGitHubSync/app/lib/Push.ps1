﻿# Push - commit and publish local changes in every repository
trap {
  Write-Host ''
  Write-Host ('  Unexpected error: ' + $_.Exception.Message) -ForegroundColor Red
  Write-Host '  Press Enter to close this window. ' -ForegroundColor DarkGray -NoNewline
  [void](Read-Host)
  exit 1
}

. (Join-Path $PSScriptRoot 'common.ps1')

Load-Config
$script:LogFile = Join-Path $script:RepoDir 'push.log'

Clear-Host
Heading 'GitHub Sync  ·  Push' 'Commit your local changes and publish them to GitHub'

if (-not (Test-Tool 'git')) {
  Write-Host '  Git is not available. Run Install.cmd again.' -ForegroundColor Red
  PauseExit 1
}

$defaultMsg = "Update from $env:COMPUTERNAME — $(Get-Date -Format 'MMM dd, yyyy HH:mm')"
Write-Host '  Commit message' -ForegroundColor White -NoNewline
Write-Host ' (press Enter to use the default)' -ForegroundColor DarkGray
Write-Host '  default:' -ForegroundColor DarkGray -NoNewline
Write-Host " $defaultMsg"
Write-Host '  > ' -NoNewline
$CommitMsg = Read-Host
if ([string]::IsNullOrWhiteSpace($CommitMsg)) { $CommitMsg = $defaultMsg }

Find-Repos
if ($script:Repos.Count -eq 0) {
  Write-Host ''
  Show-NoReposNotice
  WriteLog "push: no repositories in $($script:RepoDir)"
  PauseExit 1
}

Write-Host ''
Field 'Folder'       $script:RepoDir
Field 'Account'      $script:GhOwner
Field 'Repositories' $script:Repos.Count
Section 'Publishing'

WriteLog "── push started ── message: $CommitMsg"
$pushed = 0; $clean = 0; $failed = 0
$total = $script:Repos.Count; $idx = 0

foreach ($repo in $script:Repos) {
  $idx++
  $name = $repo.Name
  $dir  = $repo.FullName
  Row $idx $total $name

  $branch = (Invoke-Git -Dir $dir -Arguments @('rev-parse','--abbrev-ref','HEAD')).Output
  if (-not $branch -or $branch -eq 'HEAD') {
    $failed++
    Failed_ 'skipped'
    Detail 'not on a branch (detached HEAD)'
    WriteLog "SKIP  $name  detached HEAD"
    continue
  }

  if ((Invoke-Git -Dir $dir -Arguments @('remote','get-url','origin')).Code -ne 0) {
    $failed++
    Warned 'skipped'
    Detail 'no "origin" remote is configured for this repository'
    WriteLog "SKIP  $name  no origin remote"
    continue
  }

  $hasUpstream = (Invoke-Git -Dir $dir -Arguments @('rev-parse','--abbrev-ref','@{u}')).Code -eq 0
  $hasCommits  = (Invoke-Git -Dir $dir -Arguments @('rev-parse','--verify','HEAD')).Code -eq 0
  $dirty       = (Invoke-Git -Dir $dir -Arguments @('status','--porcelain')).Output
  $ahead       = ''
  if ($hasUpstream) { $ahead = (Invoke-Git -Dir $dir -Arguments @('log','@{u}..HEAD','--oneline')).Output }

  if (-not $dirty -and -not $hasCommits) {
    # Cloned from a repository that has no commits yet, and nothing added since.
    $clean++
    Neutral 'empty repository'
    WriteLog "OK    $name  empty repository"
    continue
  }

  if (-not $dirty -and $hasUpstream -and -not $ahead) {
    $clean++
    Neutral 'no changes'
    WriteLog "OK    $name  clean"
    continue
  }

  Working 'staging'
  $r = Invoke-Git -Dir $dir -Arguments @('add','-A')
  if ($r.Code -ne 0) {
    ClearWorking; Row $idx $total $name
    $failed++; Failed_ 'failed to stage'; Detail $r.Output
    WriteLog "FAIL  $name  add: $(Flat $r.Output)"
    continue
  }

  $files = @((Invoke-Git -Dir $dir -Arguments @('diff','--cached','--name-only')).Output -split "`n" |
             Where-Object { $_.Trim().Length -gt 0 }).Count

  ClearWorking; Row $idx $total $name; Working 'committing'
  if ((Invoke-Git -Dir $dir -Arguments @('status','--porcelain')).Output) {
    $r = Invoke-Git -Dir $dir -Arguments @('commit','-m',$CommitMsg)
    if ($r.Code -ne 0) {
      ClearWorking; Row $idx $total $name
      $failed++; Failed_ 'failed to commit'; Detail $r.Output
      WriteLog "FAIL  $name  commit: $(Flat $r.Output)"
      continue
    }
  }

  if ($hasUpstream) {
    ClearWorking; Row $idx $total $name; Working 'syncing'
    $r = Invoke-Git -Dir $dir -Arguments @('pull','--rebase','--autostash')
    if ($r.Code -ne 0) {
      [void](Invoke-Git -Dir $dir -Arguments @('rebase','--abort'))
      ClearWorking; Row $idx $total $name
      $failed++; Warned 'conflict — needs manual merge'; Detail $r.Output
      WriteLog "FAIL  $name  rebase: $(Flat $r.Output)"
      continue
    }
  }

  ClearWorking; Row $idx $total $name; Working 'pushing'
  if ($hasUpstream) {
    $r = Invoke-Git -Dir $dir -Arguments @('push')
  } else {
    $r = Invoke-Git -Dir $dir -Arguments @('push','-u','origin',$branch)
  }

  ClearWorking; Row $idx $total $name
  if ($r.Code -ne 0) {
    $failed++; Failed_ 'failed to push'; Detail $r.Output
    WriteLog "FAIL  $name  push: $(Flat $r.Output)"
  } else {
    $pushed++
    if ($files -gt 0) { Ok "pushed ($files file(s))" } else { Ok 'pushed' }
    WriteLog "OK    $name  pushed to $branch"
  }
}

Write-Host ''
Rule
Write-Host '  Summary' -ForegroundColor White -NoNewline
Write-Host '     ' -NoNewline
Write-Host "$pushed pushed" -ForegroundColor Green -NoNewline
Write-Host '   ·   ' -ForegroundColor DarkGray -NoNewline
Write-Host "$clean unchanged" -ForegroundColor DarkGray -NoNewline
Write-Host '   ·   ' -ForegroundColor DarkGray -NoNewline
Write-Host "$failed failed" -ForegroundColor $(if ($failed -gt 0) { 'Red' } else { 'DarkGray' })
Write-Host '  Log' -ForegroundColor White -NoNewline
Write-Host '         ' -NoNewline
Write-Host $script:LogFile -ForegroundColor DarkGray
Rule

if ($failed -gt 0) {
  Write-Host ''
  Write-Host '  Some repositories were not published. See the log for details.' -ForegroundColor Yellow
}
WriteLog "── push finished: $pushed pushed, $clean clean, $failed failed ──"
PauseExit 0
