﻿# Push - commit and publish local changes in every repository
trap {
  Write-Host ''
  Write-Host ('  × Unexpected error: ' + $_.Exception.Message) -ForegroundColor Red
  Write-Host '  ↵  press enter to close ' -ForegroundColor DarkGray -NoNewline
  [void](Read-Host)
  exit 1
}

. (Join-Path $PSScriptRoot 'common.ps1')

Set-Theme 'push'
Load-Config
$script:LogFile = Join-Path $script:RepoDir 'push.log'

Clear-Host
Banner 'PUSH' 'Commit your local changes and publish them to GitHub'
Write-Host ''
Boot @('Priming uplink array', 'Scanning repositories for changes', 'Checking GitHub credentials')

if (-not (Test-Tool 'git')) {
  Write-Host ''
  BoxTop 'MISSING TOOL'
  BoxRow @( ,@('Git is not available. Run Install.cmd again.', 'Red') )
  BoxBot
  PauseExit 1
}

$defaultMsg = "Update from $env:COMPUTERNAME — $(Get-Date -Format 'MMM dd, yyyy HH:mm')"
Write-Host ''
BoxTop 'COMMIT MESSAGE'
BoxRow @( ,@('Press Enter to use the default:', 'DarkGray') )
BoxRow $defaultMsg
BoxBot
Write-Host '  › ' -ForegroundColor $script:Acc -NoNewline
$CommitMsg = Read-Host
if ([string]::IsNullOrWhiteSpace($CommitMsg)) { $CommitMsg = $defaultMsg }

Find-Repos
if ($script:Repos.Count -eq 0) {
  Show-NoReposNotice
  WriteLog "push: no repositories in $($script:RepoDir)"
  PauseExit 1
}

Write-Host ''
BoxTop 'TARGET'
Kv 'Folder'       $script:RepoDir
Kv 'Account'      $script:GhOwner
Kv 'Repositories' ([string]$script:Repos.Count)
BoxBot
Section 'PUBLISHING'

WriteLog "── push started ── message: $CommitMsg"
$pushed = 0; $clean = 0; $conflicts = 0; $failed = 0
$total = $script:Repos.Count; $idx = 0

foreach ($repo in $script:Repos) {
  $idx++
  $name = $repo.Name
  $dir  = $repo.FullName
  Row $idx $total $name

  $branch = (Invoke-Git -Dir $dir -Arguments @('rev-parse','--abbrev-ref','HEAD')).Output
  $hasCommits = (Invoke-Git -Dir $dir -Arguments @('rev-parse','--verify','HEAD')).Code -eq 0
  $dirty      = (Invoke-Git -Dir $dir -Arguments @('status','--porcelain')).Output

  if (-not $dirty -and -not $hasCommits) {
    # Cloned from a repository that has no commits yet, and nothing added since.
    $clean++; Neutral 'empty repository'
    WriteLog "OK    $name  empty repository"
    continue
  }
  if ($hasCommits -and (-not $branch -or $branch -eq 'HEAD')) {
    $failed++; Failed_ 'skipped — not on a branch'
    Detail 'detached HEAD: check out a branch in this repo, then push again'
    WriteLog "SKIP  $name  detached HEAD"
    continue
  }
  if ((Invoke-Git -Dir $dir -Arguments @('remote','get-url','origin')).Code -ne 0) {
    $failed++; Warned 'skipped — no "origin" remote'
    Detail 'this repository has no remote configured to push to'
    WriteLog "SKIP  $name  no origin remote"
    continue
  }

  # A branch with no upstream has never been published. It can't be
  # pulled, and it always needs pushing — so it skips both the
  # "nothing to do" check and the sync step, and is pushed with -u.
  $hasUpstream = Test-Upstream $dir
  $ahead = 0
  if ($hasUpstream) {
    [void][int]::TryParse((Invoke-Git -Dir $dir -Arguments @('rev-list','--count','@{u}..HEAD')).Output, [ref]$ahead)
  }
  if (-not $dirty -and $hasUpstream -and $ahead -eq 0) {
    $clean++; Neutral 'no changes'
    WriteLog "OK    $name  clean"
    continue
  }

  $files = 0
  if ($dirty) {
    $r = Invoke-Git -Dir $dir -Arguments @('add','-A') -Label 'staging'
    if ($r.Code -ne 0) {
      $failed++; Failed_ "couldn't stage changes"; Detail $r.Output
      WriteLog "FAIL  $name  add: $(Flat $r.Output)"
      continue
    }
    $files = @((Invoke-Git -Dir $dir -Arguments @('diff','--cached','--name-only')).Output -split "`n" |
               Where-Object { $_.Trim().Length -gt 0 }).Count
    if ($files -gt 0) {
      $r = Invoke-Git -Dir $dir -Arguments @('commit','-m',$CommitMsg) -Label 'committing'
      if ($r.Code -ne 0) {
        $failed++; Failed_ "couldn't commit"; Detail $r.Output
        WriteLog "FAIL  $name  commit: $(Flat $r.Output)"
        continue
      }
    }
  }
  if (-not $branch -or $branch -eq 'HEAD') {
    $branch = (Invoke-Git -Dir $dir -Arguments @('rev-parse','--abbrev-ref','HEAD')).Output
  }

  # Bring in whatever landed on GitHub since the last pull — another
  # machine, a cloud agent, a merged PR — and replay this commit on top.
  # Without it the push below is rejected as non-fast-forward.
  if ($hasUpstream) {
    $s = Sync-Remote $dir
    if ($s -eq 1) {
      $conflicts++; Warned 'conflict — needs a manual merge'
      Detail 'the same lines changed here and on GitHub; nothing was lost, your commit is still local'
      WriteLog "CONF  $name  rebase conflict, aborted: $(Flat $script:SyncOut)"
      continue
    }
    if ($s -eq 2) {
      $failed++; Failed_ "couldn't reach GitHub"; Detail $script:SyncOut
      WriteLog "FAIL  $name  pull: $(Flat $script:SyncOut)"
      continue
    }
  }

  if ($hasUpstream) {
    $r = Invoke-Git -Dir $dir -Arguments @('push') -Label 'pushing'
  } else {
    $r = Invoke-Git -Dir $dir -Arguments @('push','-u','origin',$branch) -Label 'publishing new branch'
  }

  if ($r.Code -ne 0) {
    $failed++; Failed_ 'push failed'; Detail $r.Output
    WriteLog "FAIL  $name  push: $(Flat $r.Output)"
  } else {
    $pushed++
    $msg = 'pushed'
    if (-not $hasUpstream) { $msg = "published $branch" }
    if ($files -gt 0) { $msg += " · $files file$(if ($files -ne 1) { 's' })" }
    Ok $msg
    WriteLog "OK    $name  pushed to $branch"
  }
}

Report @( @('pushed', $pushed, 'Green'), @('unchanged', $clean, 'DarkGray'),
          @('conflicts', $conflicts, 'Yellow'), @('failed', $failed, 'Red') )

if ($conflicts -gt 0) {
  Write-Host ''
  Write-Host '  ▲ Conflicted repos were rolled back untouched. Merge them by hand, then push again.' -ForegroundColor Yellow
}
if ($failed -gt 0) {
  Write-Host ''
  Write-Host '  × Some repositories were not published. The log has the full Git output.' -ForegroundColor Red
}
WriteLog "── push finished: $pushed pushed, $clean clean, $conflicts conflicts, $failed failed ──"
PauseExit 0
