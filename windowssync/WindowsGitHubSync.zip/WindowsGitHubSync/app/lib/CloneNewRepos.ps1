﻿# Clone New Repos - download any repositories not present locally
trap {
  Write-Host ''
  Write-Host ('  × Unexpected error: ' + $_.Exception.Message) -ForegroundColor Red
  Write-Host '  ↵  press enter to close ' -ForegroundColor DarkGray -NoNewline
  [void](Read-Host)
  exit 1
}

. (Join-Path $PSScriptRoot 'common.ps1')

Set-Theme 'clone'
Load-Config
$script:LogFile = Join-Path $script:RepoDir 'pull.log'

Clear-Host
Banner 'CLONE' "Download any repositories on the account that aren't on this PC yet"
Write-Host ''
Boot @('Locating GitHub CLI', 'Verifying sign-in')

if (-not (Test-Tool 'gh')) {
  Write-Host ''
  BoxTop 'MISSING TOOL'
  BoxRow @( ,@('The GitHub CLI is not available. Run Install.cmd again.', 'Red') )
  BoxBot
  PauseExit 1
}
if ((Invoke-Gh -Arguments @('auth','status')).Code -ne 0) {
  Write-Host ''
  Write-Host '  ▲ You are signed out of GitHub. Starting sign-in...' -ForegroundColor Yellow
  Write-Host ''
  & gh auth login --hostname github.com --git-protocol https --web
  if ($LASTEXITCODE -ne 0) { PauseExit 1 }
  Write-Host ''
}

$r = Invoke-Gh -Arguments @('repo','list',$script:GhOwner,'--limit','300','--no-archived','--json','name','--jq','.[].name')
$names = @()
if ($r.Code -eq 0) {
  $names = @($r.Output -split "`n" | ForEach-Object { $_.Trim() } | Where-Object { $_.Length -gt 0 })
}
if ($names.Count -eq 0) {
  Write-Host ''
  BoxTop 'NOTHING FOUND'
  BoxRow @( ,@("No repositories found for `"$($script:GhOwner)`".", 'Yellow') )
  BoxRow @( ,@((Fit "The account name is stored in $Conf" ($Width - 8)), 'DarkGray') )
  BoxBot
  PauseExit 1
}
$total = $names.Count

Write-Host ''
BoxTop 'ACCOUNT'
Kv 'Folder'  $script:RepoDir
Kv 'Account' $script:GhOwner
Kv 'Found'   "$total on GitHub"
BoxBot
Section 'CLONING'

$new = 0; $have = 0; $failed = 0; $idx = 0
foreach ($name in $names) {
  $idx++
  Row $idx $total $name
  if (Test-Path -LiteralPath (Join-Path $script:RepoDir "$name\.git")) {
    $have++; Neutral 'already local'
    continue
  }
  $c = Invoke-Gh -Dir $script:RepoDir -Arguments @('repo','clone',"$($script:GhOwner)/$name") -Label 'cloning'
  if ($c.Code -eq 0) {
    $new++; Ok 'cloned'; WriteLog "CLONE $name"
  } else {
    $failed++; Failed_ 'failed'; Detail $c.Output
    WriteLog "FAIL  clone ${name}: $(Flat $c.Output)"
  }
}

Report @( @('cloned', $new, 'Green'), @('already local', $have, 'DarkGray'), @('failed', $failed, 'Red') )
PauseExit 0
