﻿# Clone New Repos - download any repositories not present locally
trap {
  Write-Host ''
  Write-Host ('  Unexpected error: ' + $_.Exception.Message) -ForegroundColor Red
  Write-Host '  Press Enter to close this window. ' -ForegroundColor DarkGray -NoNewline
  [void](Read-Host)
  exit 1
}

. (Join-Path $PSScriptRoot 'common.ps1')

Load-Config
$script:LogFile = Join-Path $script:RepoDir 'pull.log'

Clear-Host
Heading 'GitHub Sync  ·  Clone New Repositories' "Download any repositories on the account that aren't on this PC yet"

if (-not (Test-Tool 'gh')) {
  Write-Host '  The GitHub CLI is not available. Run Install.cmd again.' -ForegroundColor Red
  PauseExit 1
}
if ((Invoke-Gh -Arguments @('auth','status')).Code -ne 0) {
  Write-Host '  You are signed out of GitHub. Starting sign-in...' -ForegroundColor Yellow
  Write-Host ''
  & gh auth login --hostname github.com --git-protocol https --web
  if ($LASTEXITCODE -ne 0) { PauseExit 1 }
  Write-Host ''
}

Field 'Folder'  $script:RepoDir
Field 'Account' $script:GhOwner

$r = Invoke-Gh -Arguments @('repo','list',$script:GhOwner,'--limit','300','--no-archived','--json','name','--jq','.[].name')
$names = @()
if ($r.Code -eq 0) {
  $names = @($r.Output -split "`n" | ForEach-Object { $_.Trim() } | Where-Object { $_.Length -gt 0 })
}
if ($names.Count -eq 0) {
  Write-Host ''
  Write-Host "  No repositories found for `"$($script:GhOwner)`"." -ForegroundColor Yellow
  Write-Host "  The account name is stored in $Conf" -ForegroundColor DarkGray
  PauseExit 1
}

$total = $names.Count
Field 'Found' "$total on GitHub"
Section 'Cloning'

$new = 0; $have = 0; $failed = 0; $idx = 0
foreach ($name in $names) {
  $idx++
  Row $idx $total $name
  if (Test-Path -LiteralPath (Join-Path $script:RepoDir "$name\.git")) {
    $have++
    Neutral 'already local'
    continue
  }
  Working 'cloning'
  $c = Invoke-Gh -Dir $script:RepoDir -Arguments @('repo','clone',"$($script:GhOwner)/$name")
  ClearWorking; Row $idx $total $name
  if ($c.Code -eq 0) {
    $new++; Ok 'cloned'; WriteLog "CLONE $name"
  } else {
    $failed++; Failed_ 'failed'; Detail $c.Output
    WriteLog "FAIL  clone ${name}: $(Flat $c.Output)"
  }
}

Write-Host ''
Rule
Write-Host '  Summary' -ForegroundColor White -NoNewline
Write-Host '     ' -NoNewline
Write-Host "$new cloned" -ForegroundColor Green -NoNewline
Write-Host '   ·   ' -ForegroundColor DarkGray -NoNewline
Write-Host "$have already local" -ForegroundColor DarkGray -NoNewline
Write-Host '   ·   ' -ForegroundColor DarkGray -NoNewline
Write-Host "$failed failed" -ForegroundColor $(if ($failed -gt 0) { 'Red' } else { 'DarkGray' })
Write-Host '  Folder' -ForegroundColor White -NoNewline
Write-Host '      ' -NoNewline
Write-Host $script:RepoDir -ForegroundColor DarkGray
Rule
PauseExit 0
