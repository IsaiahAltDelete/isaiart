﻿# ============================================================
#  common.ps1 - shared UI kit and git helpers for GitHub Sync
#
#  Targets Windows PowerShell 5.1 in both the classic console
#  and Windows Terminal: colours are the 16 ConsoleColors, and
#  every glyph is one the default console fonts can draw.
# ============================================================

$ErrorActionPreference = 'Continue'
$ProgressPreference    = 'SilentlyContinue'

try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch { }

$GsVersion = '2.0'
$Conf      = Join-Path $env:USERPROFILE '.githubsync.conf'
$ToolDir   = Join-Path $env:USERPROFILE '.githubsync'
$Width     = 72

# Private tools first, then the usual places Git and gh land on Windows.
$extraPaths = @(
  (Join-Path $ToolDir 'bin')
  (Join-Path $ToolDir 'git\cmd')
  (Join-Path $ToolDir 'git\mingw64\bin')
  (Join-Path $ToolDir 'git\usr\bin')
  (Join-Path $env:LOCALAPPDATA 'Programs\Git\cmd')
  (Join-Path $env:LOCALAPPDATA 'Microsoft\WinGet\Links')
  "$env:ProgramFiles\Git\cmd"
  "$env:ProgramFiles\GitHub CLI"
)
foreach ($p in $extraPaths) {
  if ($p -and ($env:PATH -notlike "*$p*")) { $env:PATH = "$p;$env:PATH" }
}

# ---------- console capability --------------------------------

# Cursor moves only work with a real console. When output is
# redirected (logs, tests) the UI falls back to plain lines.
$script:HasConsole = $true
try { [void][Console]::CursorLeft; if ([Console]::IsOutputRedirected) { $script:HasConsole = $false } }
catch { $script:HasConsole = $false }

# ---------- theme ----------------------------------------------

$script:Palettes = @{
  pull  = @('White','Cyan','Cyan','DarkCyan','Blue','DarkBlue')
  push  = @('White','Magenta','Magenta','DarkMagenta','Blue','DarkBlue')
  clone = @('White','Green','Green','DarkGreen','Cyan','DarkCyan')
  setup = @('White','Yellow','Yellow','DarkYellow','Red','DarkRed')
}
$script:Palette = $script:Palettes.setup
$script:Acc     = 'Yellow'

function Set-Theme([string]$Name) {
  if ($script:Palettes.ContainsKey($Name)) { $script:Palette = $script:Palettes[$Name] }
  $script:Acc = switch ($Name) { 'pull' { 'Cyan' } 'push' { 'Magenta' } 'clone' { 'Green' } default { 'Yellow' } }
}

# ---------- banners (ANSI Shadow lettering) ---------------------

$script:Banners = @{
  PULL = @(
    '██████╗ ██╗   ██╗██╗     ██╗'
    '██╔══██╗██║   ██║██║     ██║'
    '██████╔╝██║   ██║██║     ██║'
    '██╔═══╝ ██║   ██║██║     ██║'
    '██║     ╚██████╔╝███████╗███████╗'
    '╚═╝      ╚═════╝ ╚══════╝╚══════╝'
  )
  PUSH = @(
    '██████╗ ██╗   ██╗███████╗██╗  ██╗'
    '██╔══██╗██║   ██║██╔════╝██║  ██║'
    '██████╔╝██║   ██║███████╗███████║'
    '██╔═══╝ ██║   ██║╚════██║██╔══██║'
    '██║     ╚██████╔╝███████║██║  ██║'
    '╚═╝      ╚═════╝ ╚══════╝╚═╝  ╚═╝'
  )
  CLONE = @(
    ' ██████╗██╗      ██████╗ ███╗   ██╗███████╗'
    '██╔════╝██║     ██╔═══██╗████╗  ██║██╔════╝'
    '██║     ██║     ██║   ██║██╔██╗ ██║█████╗'
    '██║     ██║     ██║   ██║██║╚██╗██║██╔══╝'
    '╚██████╗███████╗╚██████╔╝██║ ╚████║███████╗'
    ' ╚═════╝╚══════╝ ╚═════╝ ╚═╝  ╚═══╝╚══════╝'
  )
  SETUP = @(
    '███████╗███████╗████████╗██╗   ██╗██████╗'
    '██╔════╝██╔════╝╚══██╔══╝██║   ██║██╔══██╗'
    '███████╗█████╗     ██║   ██║   ██║██████╔╝'
    '╚════██║██╔══╝     ██║   ██║   ██║██╔═══╝'
    '███████║███████╗   ██║   ╚██████╔╝██║'
    '╚══════╝╚══════╝   ╚═╝    ╚═════╝ ╚═╝'
  )
}

function Banner([string]$Word, [string]$Subtitle) {
  Write-Host ''
  $lines = $script:Banners[$Word]
  for ($i = 0; $i -lt $lines.Count; $i++) {
    Write-Host ('  ' + $lines[$i]) -ForegroundColor $script:Palette[$i]
  }
  Write-Host ''
  $tag  = 'GITHUB SYNC'
  $meta = "v$GsVersion · Windows"
  $gap  = $Width - 2 - ("░▒▓ $tag ▓▒░").Length - $meta.Length
  if ($gap -lt 2) { $gap = 2 }
  Write-Host '  ░▒▓ ' -ForegroundColor $script:Acc -NoNewline
  Write-Host $tag -ForegroundColor White -NoNewline
  Write-Host ' ▓▒░' -ForegroundColor $script:Acc -NoNewline
  Write-Host ((' ' * $gap) + $meta) -ForegroundColor DarkGray
  if ($Subtitle) { Write-Host "  $Subtitle" -ForegroundColor Gray }
  Write-Host ('  ' + ('═' * ($Width - 2))) -ForegroundColor DarkGray
}
function Heading([string]$Title, [string]$Subtitle) { Banner $Title $Subtitle }

# ---------- boxes -----------------------------------------------

# Shortens long values: the profile folder becomes ~, anything still
# too long loses its middle to an ellipsis.
function Fit([string]$Text, [int]$Max) {
  if (-not $Text) { return '' }
  if ($env:USERPROFILE -and $Text.StartsWith($env:USERPROFILE, [StringComparison]::OrdinalIgnoreCase)) {
    $Text = '~' + $Text.Substring($env:USERPROFILE.Length)
  }
  if ($Text.Length -le $Max) { return $Text }
  $keep = [int][Math]::Floor(($Max - 1) / 2)
  return $Text.Substring(0, $keep) + '…' + $Text.Substring($Text.Length - ($Max - 1 - $keep))
}

function BoxTop([string]$Title) {
  $inner = $Width - 4
  if ($Title) {
    Write-Host '  ┌─ ' -ForegroundColor DarkGray -NoNewline
    Write-Host $Title -ForegroundColor $script:Acc -NoNewline
    Write-Host (' ' + ('─' * ($inner - $Title.Length - 3)) + '┐') -ForegroundColor DarkGray
  } else {
    Write-Host ('  ┌' + ('─' * $inner) + '┐') -ForegroundColor DarkGray
  }
}
function BoxBot { Write-Host ('  └' + ('─' * ($Width - 4)) + '┘') -ForegroundColor DarkGray }

# BoxRow takes segments: @( @('text','Color'), @('more','Color') )
function BoxRow($Segments) {
  if ($Segments -is [string]) { $Segments = ,@($Segments, 'Gray') }
  Write-Host '  │ ' -ForegroundColor DarkGray -NoNewline
  $len = 0
  foreach ($s in $Segments) { Write-Host $s[0] -ForegroundColor $s[1] -NoNewline; $len += $s[0].Length }
  $pad = $Width - 6 - $len
  if ($pad -lt 0) { $pad = 0 }
  Write-Host ((' ' * $pad) + ' │') -ForegroundColor DarkGray
}
function Kv([string]$Label, [string]$Value) {
  BoxRow @( @($Label.PadRight(14), 'DarkGray'), @((Fit $Value ($Width - 21)), 'Gray') )
}
function Field([string]$Label, [string]$Value) { Kv $Label $Value }

function Section([string]$Title) {
  Write-Host ''
  Write-Host '  ┌─[ ' -ForegroundColor DarkGray -NoNewline
  Write-Host $Title -ForegroundColor $script:Acc -NoNewline
  Write-Host (' ]' + ('─' * ($Width - 8 - $Title.Length))) -ForegroundColor DarkGray
  Write-Host ''
}

# A few quick status lines. Set GS_FAST=1 to skip the animation.
function Boot([string[]]$Steps) {
  foreach ($s in $Steps) {
    Write-Host '  ► ' -ForegroundColor $script:Acc -NoNewline
    Write-Host $s -ForegroundColor DarkGray -NoNewline
    $n = [Math]::Max(3, 40 - $s.Length)
    for ($i = 0; $i -lt $n; $i++) {
      Write-Host '.' -ForegroundColor DarkGray -NoNewline
      if (-not $env:GS_FAST -and $script:HasConsole) { Start-Sleep -Milliseconds 10 }
    }
    Write-Host ' [ OK ]' -ForegroundColor Green
  }
}

# ---------- repo rows -------------------------------------------

# Row prints the left half and remembers where it ended, so a spinner
# and then the result can be drawn in the same spot.
function Row([int]$Index, [int]$Total, [string]$Name) {
  $n = 40 - $Name.Length
  if ($n -lt 2) { $n = 2 }
  Write-Host '  ▐' -ForegroundColor DarkGray -NoNewline
  Write-Host ('{0:D2}' -f $Index) -ForegroundColor $script:Acc -NoNewline
  Write-Host ('/{0:D2}' -f $Total) -ForegroundColor DarkGray -NoNewline
  Write-Host '▌ ' -ForegroundColor DarkGray -NoNewline
  Write-Host $Name -ForegroundColor White -NoNewline
  Write-Host (' ' + ('·' * $n) + ' ') -ForegroundColor DarkGray -NoNewline
  if ($script:HasConsole) { $script:RowX = [Console]::CursorLeft; $script:RowY = [Console]::CursorTop }
}

function Reset-Row {
  if (-not $script:HasConsole) { return }
  try {
    [Console]::SetCursorPosition($script:RowX, $script:RowY)
    $w = [Console]::BufferWidth - $script:RowX - 1
    if ($w -gt 0) { Write-Host (' ' * $w) -NoNewline }
    [Console]::SetCursorPosition($script:RowX, $script:RowY)
  } catch { }
}

function Ok([string]$t)       { Reset-Row; Write-Host "√ $t" -ForegroundColor Green }
function Neutral([string]$t)  { Reset-Row; Write-Host "· $t" -ForegroundColor DarkGray }
function Warned([string]$t)   { Reset-Row; Write-Host "▲ $t" -ForegroundColor Yellow }
function Failed_([string]$t)  { Reset-Row; Write-Host "× $t" -ForegroundColor Red }
function Working([string]$t)  { if ($script:HasConsole) { Reset-Row; Write-Host $t -ForegroundColor DarkGray -NoNewline } }
function ClearWorking         { Reset-Row }

# up to 3 indented explanation lines
function Detail([string]$Text) {
  if (-not $Text) { return }
  $lines = @($Text -split "`r?`n" | Where-Object { $_.Trim().Length -gt 0 -and $_ -notmatch '^\s*hint:' } | Select-Object -First 3)
  foreach ($l in $lines) {
    Write-Host '           │ ' -ForegroundColor DarkGray -NoNewline
    Write-Host $l.Trim() -ForegroundColor DarkGray
  }
}

# ---------- report ----------------------------------------------

$script:StartTime = Get-Date
function Elapsed {
  $s = [int]((Get-Date) - $script:StartTime).TotalSeconds
  if ($s -ge 60) { return ('{0}m {1:D2}s' -f [int][Math]::Floor($s / 60), ($s % 60)) }
  return "${s}s"
}

# Report @( @('pushed', 3, 'Green'), ... ) — boxed tally and a stacked bar.
function Report($Items) {
  $total = 0
  foreach ($it in $Items) { $total += [int]$it[1] }
  $w = $Width - 10
  Write-Host ''
  BoxTop 'REPORT'
  foreach ($it in $Items) {
    BoxRow @( @('■ ', $it[2]), @(([string]$it[0]).PadRight(16), 'Gray'), @(([string]$it[1]).PadLeft(3), 'White') )
  }
  BoxRow ''
  # The bar is drawn segment by segment so each keeps its colour.
  Write-Host '  │ ' -ForegroundColor DarkGray -NoNewline
  $used = 0
  foreach ($it in $Items) {
    $c = [int]$it[1]
    $seg = 0
    if ($total -gt 0) { $seg = [int][Math]::Round($c * $w / $total) }
    if ($c -gt 0 -and $seg -eq 0) { $seg = 1 }
    if ($seg -gt 0) { Write-Host ('█' * $seg) -ForegroundColor $it[2] -NoNewline; $used += $seg }
  }
  $pad = $Width - 6 - $used
  if ($pad -lt 0) { $pad = 0 }
  Write-Host ((' ' * $pad) + ' │') -ForegroundColor DarkGray
  BoxRow ''
  Kv 'Time' (Elapsed)
  if ($script:LogFile) { Kv 'Log' $script:LogFile }
  BoxBot
}

function WriteLog([string]$Message) {
  if (-not $script:LogFile) { return }
  try {
    ('{0}  {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Message) |
      Add-Content -LiteralPath $script:LogFile -Encoding UTF8 -ErrorAction SilentlyContinue
  } catch { }
}

function PauseExit([int]$Code = 0) {
  Write-Host ''
  Write-Host '  ↵  press enter to close ' -ForegroundColor DarkGray -NoNewline
  [void](Read-Host)
  exit $Code
}

# ---------- process helpers ---------------------------------

# Quotes one argument the way CommandLineToArgvW expects to read it back.
function Quote-Arg {
  param([string]$Value)
  if ($null -eq $Value -or $Value -eq '') { return '""' }
  if ($Value -notmatch '[\s"]') { return $Value }
  $escaped = $Value -replace '(\\*)"', '$1$1\"'
  $escaped = $escaped -replace '(\\+)$', '$1$1'
  return '"' + $escaped + '"'
}

$script:Spin = @('■□□□', '□■□□', '□□■□', '□□□■', '□□■□', '□■□□')

# Runs a native command in $Dir and returns @{ Output = <stdout+stderr>; Code = <exit code> }.
# Uses Process directly rather than the call operator: PowerShell 5.1 wraps a native
# command's stderr in error-record formatting, which would end up in the log.
# With -Label, a spinner runs after the current row while the command works.
function Invoke-Tool {
  param(
    [Parameter(Mandatory=$true)][string]$Exe,
    [string[]]$Arguments = @(),
    [string]$Dir = $null,
    [string]$Label = $null
  )
  $path = $Exe
  $cmd  = Get-Command $Exe -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
  if ($cmd) { $path = $cmd.Source }

  $psi = New-Object System.Diagnostics.ProcessStartInfo
  $psi.FileName               = $path
  $psi.Arguments              = (($Arguments | ForEach-Object { Quote-Arg $_ }) -join ' ')
  $psi.UseShellExecute        = $false
  $psi.CreateNoWindow         = $true
  $psi.RedirectStandardOutput = $true
  $psi.RedirectStandardError  = $true
  if ($Dir) { $psi.WorkingDirectory = $Dir }
  try {
    $psi.StandardOutputEncoding = [System.Text.Encoding]::UTF8
    $psi.StandardErrorEncoding  = [System.Text.Encoding]::UTF8
  } catch { }

  $stdout = ''; $stderr = ''; $code = 1
  try {
    $p  = [System.Diagnostics.Process]::Start($psi)
    # Read both streams concurrently, or a full pipe buffer on one deadlocks the other.
    $so = $p.StandardOutput.ReadToEndAsync()
    $se = $p.StandardError.ReadToEndAsync()
    if ($Label -and $script:HasConsole) {
      $i = 0
      try { [Console]::CursorVisible = $false } catch { }
      while (-not $p.WaitForExit(90)) {
        Reset-Row
        Write-Host $script:Spin[$i % $script:Spin.Count] -ForegroundColor $script:Acc -NoNewline
        Write-Host " $Label" -ForegroundColor DarkGray -NoNewline
        $i++
      }
      try { [Console]::CursorVisible = $true } catch { }
    }
    $p.WaitForExit()
    $stdout = $so.Result
    $stderr = $se.Result
    $code   = $p.ExitCode
    $p.Dispose()
  } catch {
    $stderr = $_.Exception.Message
    $code   = 1
  }

  [pscustomobject]@{
    Output = ((("$stdout`n$stderr") -replace "`r", '').Trim())
    Code   = $code
  }
}

function Invoke-Git { param([string]$Dir, [string[]]$Arguments, [string]$Label)
  Invoke-Tool -Exe 'git' -Arguments $Arguments -Dir $Dir -Label $Label
}

function Invoke-Gh { param([string]$Dir, [string[]]$Arguments, [string]$Label)
  Invoke-Tool -Exe 'gh' -Arguments $Arguments -Dir $Dir -Label $Label
}

function Test-Tool([string]$Name) {
  return [bool](Get-Command $Name -ErrorAction SilentlyContinue)
}

# ---------- git helpers -------------------------------------

function Test-Upstream([string]$Dir) {
  (Invoke-Git -Dir $Dir -Arguments @('rev-parse','--abbrev-ref','--symbolic-full-name','@{u}')).Code -eq 0
}

function Test-RebaseInProgress([string]$Dir) {
  $g = (Invoke-Git -Dir $Dir -Arguments @('rev-parse','--git-dir')).Output
  if (-not $g) { return $false }
  if (-not [System.IO.Path]::IsPathRooted($g)) { $g = Join-Path $Dir $g }
  return ((Test-Path -LiteralPath (Join-Path $g 'rebase-merge')) -or (Test-Path -LiteralPath (Join-Path $g 'rebase-apply')))
}

# Sync-Remote: pull --rebase --autostash, and classify what happened:
#   0 ok · 1 real conflict (rolled back) · 2 other failure (network,
#   sign-in...) · 3 rebased, but uncommitted edits clashed on re-apply
# Only 1 needs a human to merge anything. Output is in $script:SyncOut.
function Sync-Remote([string]$Dir) {
  $r = Invoke-Git -Dir $Dir -Arguments @('pull','--rebase','--autostash') -Label 'syncing with GitHub'
  $script:SyncOut = $r.Output
  if ($r.Code -ne 0) {
    if (Test-RebaseInProgress $Dir) {
      [void](Invoke-Git -Dir $Dir -Arguments @('rebase','--abort'))
      return 1
    }
    return 2
  }
  if ($r.Output -match '(?i)autostash resulted in conflicts') { return 3 }
  return 0
}

# ---------- configuration -----------------------------------

function Load-Config {
  if (-not (Test-Path -LiteralPath $Conf)) {
    Write-Host ''
    BoxTop 'NOT SET UP'
    BoxRow 'Setup has not been run on this PC yet.'
    BoxRow 'Please run Install.cmd first.'
    BoxBot
    PauseExit 1
  }
  $script:RepoDir = $null
  $script:GhOwner = $null
  foreach ($line in (Get-Content -LiteralPath $Conf -ErrorAction SilentlyContinue)) {
    if ($line -match '^\s*#') { continue }
    if ($line -match '^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$') {
      $key = $Matches[1]
      $val = $Matches[2].Trim().Trim('"')
      switch ($key) {
        'REPO_DIR' { $script:RepoDir = $val }
        'GH_OWNER' { $script:GhOwner = $val }
      }
    }
  }
  if (-not $script:RepoDir -or -not (Test-Path -LiteralPath $script:RepoDir)) {
    Write-Host ''
    BoxTop 'FOLDER MISSING'
    BoxRow 'Projects folder not found:'
    BoxRow @( ,@((Fit ([string]$script:RepoDir) ($Width - 8)), 'DarkGray') )
    BoxRow 'Run Install.cmd again to point it somewhere else.'
    BoxBot
    PauseExit 1
  }
}

function Find-Repos {
  $script:Repos = @()
  if (-not (Test-Path -LiteralPath $script:RepoDir)) { return }
  $script:Repos = @(
    Get-ChildItem -LiteralPath $script:RepoDir -Directory -ErrorAction SilentlyContinue |
      Where-Object { Test-Path -LiteralPath (Join-Path $_.FullName '.git') } |
      Sort-Object Name
  )
}

function Show-NoReposNotice {
  Write-Host ''
  BoxTop 'NO REPOSITORIES'
  BoxRow @( ,@('No Git projects were found in this folder.', 'Yellow') )
  Kv 'Folder' $script:RepoDir
  BoxRow 'Run "Clone New Repos.cmd" to download them.'
  BoxBot
}

# collapses multi-line command output onto one log line
function Flat([string]$Text) {
  if (-not $Text) { return '' }
  return (($Text -split "`r?`n" | Where-Object { $_.Trim().Length -gt 0 }) -join ' | ')
}
