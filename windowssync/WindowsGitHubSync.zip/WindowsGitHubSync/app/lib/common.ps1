﻿# ============================================================
#  common.ps1 - shared helpers for the GitHub Sync scripts
# ============================================================

$ErrorActionPreference = 'Continue'
$ProgressPreference    = 'SilentlyContinue'

try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch { }

$Conf    = Join-Path $env:USERPROFILE '.githubsync.conf'
$ToolDir = Join-Path $env:USERPROFILE '.githubsync'
$Width   = 68

# Private tools first, then the usual places Git and gh land on Windows.
$extraPaths = @(
  (Join-Path $ToolDir 'bin')
  (Join-Path $ToolDir 'git\cmd')
  (Join-Path $ToolDir 'git\mingw64\bin')
  (Join-Path $ToolDir 'git\usr\bin')
  (Join-Path $env:LOCALAPPDATA 'Programs\Git\cmd')
  (Join-Path $env:LOCALAPPDATA 'Microsoft\WinGet\Links')
  "$env:ProgramFiles\Git\cmd"
  "$env:ProgramFiles\GitHub CLI"
)
foreach ($p in $extraPaths) {
  if ($p -and ($env:PATH -notlike "*$p*")) { $env:PATH = "$p;$env:PATH" }
}

# ---------- presentation ------------------------------------

function Rule { Write-Host (([string][char]0x2500) * $Width) -ForegroundColor DarkGray }

function Heading([string]$Title, [string]$Subtitle) {
  Write-Host ''
  Rule
  Write-Host "  $Title" -ForegroundColor White
  if ($Subtitle) { Write-Host "  $Subtitle" -ForegroundColor DarkGray }
  Rule
  Write-Host ''
}

function Field([string]$Label, [string]$Value) {
  Write-Host ('  ' + $Label.PadRight(15)) -ForegroundColor DarkGray -NoNewline
  Write-Host $Value
}

function Section([string]$Title) {
  Write-Host ''
  Write-Host "  $Title" -ForegroundColor White
  Write-Host ''
}

# Row  index  total  name   -> prints the left-hand part, no newline
function Row([int]$Index, [int]$Total, [string]$Name) {
  $tag = "[$Index/$Total]"
  $n = 42 - $Name.Length
  if ($n -lt 2) { $n = 2 }
  Write-Host ('  ' + $tag.PadRight(7)) -ForegroundColor DarkGray -NoNewline
  Write-Host " $Name " -NoNewline
  Write-Host ('.' * $n) -ForegroundColor DarkGray -NoNewline
  Write-Host ' ' -NoNewline
}

function Ok([string]$t)       { Write-Host $t -ForegroundColor Green }
function Neutral([string]$t)  { Write-Host $t -ForegroundColor DarkGray }
function Warned([string]$t)   { Write-Host $t -ForegroundColor Yellow }
function Failed_([string]$t)  { Write-Host $t -ForegroundColor Red }
function Working([string]$t)  { Write-Host $t -ForegroundColor DarkGray -NoNewline }

function ClearWorking {
  $w = 80
  try { $w = [Console]::BufferWidth } catch { }
  if ($w -lt 2) { $w = 80 }
  Write-Host ("`r" + (' ' * ($w - 1)) + "`r") -NoNewline
}

# indented dim explanation lines, max 3
function Detail([string]$Text) {
  if (-not $Text) { return }
  $lines = @($Text -split "`r?`n" | Where-Object { $_.Trim().Length -gt 0 } | Select-Object -First 3)
  foreach ($l in $lines) { Write-Host ('           ' + $l.Trim()) -ForegroundColor DarkGray }
}

function WriteLog([string]$Message) {
  if (-not $script:LogFile) { return }
  try {
    ('{0}  {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Message) |
      Add-Content -LiteralPath $script:LogFile -Encoding UTF8 -ErrorAction SilentlyContinue
  } catch { }
}

function PauseExit([int]$Code = 0) {
  Write-Host ''
  Write-Host '  Press Enter to close this window. ' -ForegroundColor DarkGray -NoNewline
  [void](Read-Host)
  exit $Code
}

# ---------- process helpers ---------------------------------

# Quotes one argument the way CommandLineToArgvW expects to read it back.
function Quote-Arg {
  param([string]$Value)
  if ($null -eq $Value -or $Value -eq '') { return '""' }
  if ($Value -notmatch '[\s"]') { return $Value }
  $escaped = $Value -replace '(\\*)"', '$1$1\"'
  $escaped = $escaped -replace '(\\+)$', '$1$1'
  return '"' + $escaped + '"'
}

# Runs a native command in $Dir and returns @{ Output = <stdout+stderr>; Code = <exit code> }.
# Uses Process directly rather than the call operator: PowerShell 5.1 wraps a native
# command's stderr in error-record formatting, which would end up in the log.
function Invoke-Tool {
  param(
    [Parameter(Mandatory=$true)][string]$Exe,
    [string[]]$Arguments = @(),
    [string]$Dir = $null
  )
  $path = $Exe
  $cmd  = Get-Command $Exe -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
  if ($cmd) { $path = $cmd.Source }

  $psi = New-Object System.Diagnostics.ProcessStartInfo
  $psi.FileName               = $path
  $psi.Arguments              = (($Arguments | ForEach-Object { Quote-Arg $_ }) -join ' ')
  $psi.UseShellExecute        = $false
  $psi.CreateNoWindow         = $true
  $psi.RedirectStandardOutput = $true
  $psi.RedirectStandardError  = $true
  if ($Dir) { $psi.WorkingDirectory = $Dir }
  try {
    $psi.StandardOutputEncoding = [System.Text.Encoding]::UTF8
    $psi.StandardErrorEncoding  = [System.Text.Encoding]::UTF8
  } catch { }

  $stdout = ''; $stderr = ''; $code = 1
  try {
    $p  = [System.Diagnostics.Process]::Start($psi)
    # Read both streams concurrently, or a full pipe buffer on one deadlocks the other.
    $so = $p.StandardOutput.ReadToEndAsync()
    $se = $p.StandardError.ReadToEndAsync()
    $p.WaitForExit()
    $stdout = $so.Result
    $stderr = $se.Result
    $code   = $p.ExitCode
    $p.Dispose()
  } catch {
    $stderr = $_.Exception.Message
    $code   = 1
  }

  [pscustomobject]@{
    Output = ((("$stdout`n$stderr") -replace "`r", '').Trim())
    Code   = $code
  }
}

function Invoke-Git { param([string]$Dir, [string[]]$Arguments)
  Invoke-Tool -Exe 'git' -Arguments $Arguments -Dir $Dir
}

function Invoke-Gh { param([string]$Dir, [string[]]$Arguments)
  Invoke-Tool -Exe 'gh' -Arguments $Arguments -Dir $Dir
}

function Test-Tool([string]$Name) {
  return [bool](Get-Command $Name -ErrorAction SilentlyContinue)
}

# ---------- configuration -----------------------------------

function Load-Config {
  if (-not (Test-Path -LiteralPath $Conf)) {
    Heading 'Setup has not been run yet' ''
    Write-Host '  Please run Install.cmd first.'
    PauseExit 1
  }
  $script:RepoDir = $null
  $script:GhOwner = $null
  foreach ($line in (Get-Content -LiteralPath $Conf -ErrorAction SilentlyContinue)) {
    if ($line -match '^\s*#') { continue }
    if ($line -match '^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$') {
      $key = $Matches[1]
      $val = $Matches[2].Trim().Trim('"')
      switch ($key) {
        'REPO_DIR' { $script:RepoDir = $val }
        'GH_OWNER' { $script:GhOwner = $val }
      }
    }
  }
  if (-not $script:RepoDir -or -not (Test-Path -LiteralPath $script:RepoDir)) {
    Heading 'Projects folder not found' $script:RepoDir
    Write-Host '  Run Install.cmd again to point it somewhere else.'
    PauseExit 1
  }
}

function Find-Repos {
  $script:Repos = @()
  if (-not (Test-Path -LiteralPath $script:RepoDir)) { return }
  $script:Repos = @(
    Get-ChildItem -LiteralPath $script:RepoDir -Directory -ErrorAction SilentlyContinue |
      Where-Object { Test-Path -LiteralPath (Join-Path $_.FullName '.git') } |
      Sort-Object Name
  )
}

function Show-NoReposNotice {
  Write-Host '  No Git projects were found in this folder.' -ForegroundColor Yellow
  Write-Host ''
  Field 'Folder' $script:RepoDir
  Write-Host ''
  Write-Host '  Run "Clone New Repos.cmd" to download them.'
}

# collapses multi-line command output onto one log line
function Flat([string]$Text) {
  if (-not $Text) { return '' }
  return (($Text -split "`r?`n" | Where-Object { $_.Trim().Length -gt 0 }) -join ' | ')
}
