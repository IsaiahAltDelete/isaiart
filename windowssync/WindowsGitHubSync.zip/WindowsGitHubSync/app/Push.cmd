@echo off
chcp 65001 >nul
title GitHub Sync - Push
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0lib\Push.ps1"
