@echo off
chcp 65001 >nul
title GitHub Sync - Clone New Repos
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0lib\CloneNewRepos.ps1"
