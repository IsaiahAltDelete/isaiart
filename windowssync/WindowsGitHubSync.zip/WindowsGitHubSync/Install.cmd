@echo off
chcp 65001 >nul
title GitHub Sync for Windows - Installer
where powershell >nul 2>nul || (
  echo.
  echo   Windows PowerShell was not found on this PC.
  echo.
  pause
  exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install.ps1"
