﻿# ============================================================
#  GitHub Sync for Windows — installer
# ============================================================
trap {
  Write-Host ''
  Write-Host ('    ✗  Unexpected error: ' + $_.Exception.Message) -ForegroundColor Red
  Write-Host ''
  Write-Host '  Press Enter to close. ' -ForegroundColor DarkGray -NoNewline
  [void](Read-Host)
  exit 1
}

$ErrorActionPreference = 'Continue'
$ProgressPreference    = 'SilentlyContinue'
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch { }
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch { }

$Here    = Split-Path -Parent $MyInvocation.MyCommand.Path
$Conf    = Join-Path $env:USERPROFILE '.githubsync.conf'
$ToolDir = Join-Path $env:USERPROFILE '.githubsync'
$BinDir  = Join-Path $ToolDir 'bin'
$GitDir  = Join-Path $ToolDir 'git'
$Width   = 68
$UA      = @{ 'User-Agent' = 'GitHubSync-Setup' }

function Rule {
  Write-Host (([string][char]0x2500) * $Width) -ForegroundColor DarkGray
}

function Step {
  param([string]$Text)
  Write-Host ''
  Write-Host "  $Text" -ForegroundColor White
  Write-Host ''
}

function Good {
  param([string]$Text)
  Write-Host '    ✓  ' -ForegroundColor Green -NoNewline
  Write-Host $Text
}

function Info {
  param([string]$Text)
  Write-Host '    ·  ' -ForegroundColor DarkGray -NoNewline
  Write-Host $Text
}

function Warn {
  param([string]$Text)
  Write-Host '    !  ' -ForegroundColor Yellow -NoNewline
  Write-Host $Text
}

function Bail {
  param([string]$Text)
  Write-Host ''
  Write-Host '    ✗  ' -ForegroundColor Red -NoNewline
  Write-Host $Text
  Write-Host ''
  Write-Host '  Press Enter to close. ' -ForegroundColor DarkGray -NoNewline
  [void](Read-Host)
  exit 1
}

function Add-ToProcessPath {
  param([string]$Dir)
  if ($Dir -and (Test-Path -LiteralPath $Dir) -and ($env:PATH -notlike "*$Dir*")) {
    $env:PATH = "$Dir;$env:PATH"
  }
}

# Rebuilds this process's PATH from the machine and user settings, with our
# private tool folders in front, so freshly installed programs become visible.
function Sync-Path {
  $parts = @()
  foreach ($dir in @($BinDir,
                     (Join-Path $GitDir 'cmd'),
                     (Join-Path $GitDir 'mingw64\bin'),
                     (Join-Path $env:LOCALAPPDATA 'Programs\Git\cmd'),
                     (Join-Path $env:LOCALAPPDATA 'Microsoft\WinGet\Links'),
                     "$env:ProgramFiles\Git\cmd",
                     "$env:ProgramFiles\GitHub CLI")) {
    if (Test-Path -LiteralPath $dir) { $parts += $dir }
  }
  foreach ($scope in @('Machine', 'User')) {
    $p = [Environment]::GetEnvironmentVariable('PATH', $scope)
    if ($p) { $parts += ($p -split ';') }
  }
  $env:PATH = (($parts | Where-Object { $_ -and $_.Trim().Length -gt 0 } | Select-Object -Unique) -join ';')
}

function Have {
  param([string]$Name)
  if (Get-Command $Name -CommandType Application -ErrorAction SilentlyContinue) { return $true }
  $candidates = @()
  if ($Name -eq 'git') {
    $candidates = @("$GitDir\cmd\git.exe",
                    "$env:LOCALAPPDATA\Programs\Git\cmd\git.exe",
                    "$env:ProgramFiles\Git\cmd\git.exe",
                    "${env:ProgramFiles(x86)}\Git\cmd\git.exe")
  } elseif ($Name -eq 'gh') {
    $candidates = @("$BinDir\gh.exe",
                    "$env:ProgramFiles\GitHub CLI\gh.exe",
                    "$env:LOCALAPPDATA\Programs\GitHub CLI\gh.exe")
  }
  foreach ($c in $candidates) {
    if ($c -and (Test-Path -LiteralPath $c)) {
      Add-ToProcessPath (Split-Path -Parent $c)
      return $true
    }
  }
  return $false
}

function Tool-Version {
  param([string]$Name, [string[]]$Arguments)
  try {
    $out = (& $Name @Arguments 2>$null | Out-String)
    return (($out -split "`r?`n") | Where-Object { $_.Trim().Length -gt 0 } | Select-Object -First 1).Trim()
  } catch { return '' }
}

function Get-File {
  param([string]$Url, [string]$OutFile)
  try {
    Invoke-WebRequest -Uri $Url -OutFile $OutFile -Headers $UA -UseBasicParsing -ErrorAction Stop
    return (Test-Path -LiteralPath $OutFile)
  } catch { return $false }
}

function Expand-Zip {
  param([string]$Zip, [string]$Dest)
  try {
    if (Get-Command Expand-Archive -ErrorAction SilentlyContinue) {
      Expand-Archive -LiteralPath $Zip -DestinationPath $Dest -Force -ErrorAction Stop
    } else {
      Add-Type -AssemblyName System.IO.Compression.FileSystem
      [System.IO.Compression.ZipFile]::ExtractToDirectory($Zip, $Dest)
    }
    return $true
  } catch { return $false }
}

Sync-Path

Clear-Host
Write-Host ''
Rule
Write-Host '  GitHub Sync for Windows' -ForegroundColor White
Write-Host '  Installer — sets up Git, signs you in, and clones your repositories' -ForegroundColor DarkGray
Rule
Write-Host ''
Write-Host '  This runs once and takes about five minutes. You will be asked to'
Write-Host '  sign in to GitHub in your web browser partway through.'
Write-Host ''
Write-Host '  It installs:'
Info 'Git for Windows, if it is not already present'
Info 'GitHub CLI, into your user folder'
Info 'Three double-clickable scripts in your projects folder'
Write-Host ''
Write-Host '  Nothing needs an administrator password.' -ForegroundColor DarkGray
Write-Host ''
Write-Host '  Press Enter to begin, or close this window to cancel. ' -ForegroundColor DarkGray -NoNewline
[void](Read-Host)

# ── 1. Git ──────────────────────────────────────────────────
Step '1 / 5   Git for Windows'
if (Have 'git') {
  Good ('Already installed — ' + (Tool-Version 'git' @('--version')))
} else {
  $installed = $false
  if (Have 'winget') {
    Info 'Installing with winget. This takes a minute or two.'
    & winget install --id Git.Git -e --source winget --scope user --silent --accept-package-agreements --accept-source-agreements 2>$null | Out-Null
    Sync-Path
    $installed = Have 'git'
    if ($installed) {
      Good ('Installed — ' + (Tool-Version 'git' @('--version')))
    } else {
      Warn 'winget could not install Git. Falling back to the portable build.'
    }
  }
  if (-not $installed) {
    Info 'Downloading portable Git from github.com (about 70 MB)...'
    try {
      $rel = Invoke-RestMethod -Uri 'https://api.github.com/repos/git-for-windows/git/releases/latest' -Headers $UA -UseBasicParsing -ErrorAction Stop
    } catch { $rel = $null }
    if (-not $rel) { Bail 'Could not reach github.com. Check the network connection and try again.' }
    $asset = $rel.assets | Where-Object { $_.name -like 'PortableGit-*-64-bit.7z.exe' } | Select-Object -First 1
    if (-not $asset) { Bail 'The latest Git release had no portable build. Install Git from git-scm.com, then run this installer again.' }

    $tmp = Join-Path $ToolDir 'tmp'
    New-Item -ItemType Directory -Force -Path $tmp    | Out-Null
    New-Item -ItemType Directory -Force -Path $BinDir | Out-Null
    $sfx = Join-Path $tmp 'PortableGit.7z.exe'
    if (-not (Get-File $asset.browser_download_url $sfx)) { Bail 'Download failed. Check the network connection.' }

    Info 'Unpacking...'
    if (Test-Path -LiteralPath $GitDir) { Remove-Item -LiteralPath $GitDir -Recurse -Force -ErrorAction SilentlyContinue }
    New-Item -ItemType Directory -Force -Path $GitDir | Out-Null
    Start-Process -FilePath $sfx -ArgumentList "-o`"$GitDir`" -y" -Wait -WindowStyle Hidden
    $post = Join-Path $GitDir 'post-install.bat'
    if (Test-Path -LiteralPath $post) {
      try { Start-Process -FilePath $post -WorkingDirectory $GitDir -Wait -WindowStyle Hidden } catch { }
    }
    Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue
    Sync-Path
    if (-not (Have 'git')) { Bail 'Git is still unavailable. Restart the PC and run this installer again.' }
    Good ("Installed to $GitDir — " + (Tool-Version 'git' @('--version')))
  }
}
if (-not (Have 'git')) { Bail 'Git is still unavailable. Restart the PC and run this installer again.' }

# ── 2. GitHub CLI ───────────────────────────────────────────
Step '2 / 5   GitHub CLI'
if (Have 'gh') {
  Good ('Already installed — ' + (Tool-Version 'gh' @('--version')))
} else {
  Info 'Downloading the official release from github.com...'
  try {
    $rel = Invoke-RestMethod -Uri 'https://api.github.com/repos/cli/cli/releases/latest' -Headers $UA -UseBasicParsing -ErrorAction Stop
  } catch { $rel = $null }
  if (-not $rel) { Bail 'Could not reach github.com. Check the network connection and try again.' }

  $ver  = ($rel.tag_name -replace '^v', '')
  $arch = 'amd64'
  if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64') { $arch = 'arm64' }
  $tmp = Join-Path $ToolDir 'tmp'
  New-Item -ItemType Directory -Force -Path $tmp    | Out-Null
  New-Item -ItemType Directory -Force -Path $BinDir | Out-Null
  $zip = Join-Path $tmp 'gh.zip'
  $url = "https://github.com/cli/cli/releases/download/v$ver/gh_${ver}_windows_$arch.zip"
  if (-not (Get-File $url $zip)) { Bail 'Download failed. Check the network connection.' }

  $x = Join-Path $tmp 'x'
  if (Test-Path -LiteralPath $x) { Remove-Item -LiteralPath $x -Recurse -Force -ErrorAction SilentlyContinue }
  if (-not (Expand-Zip $zip $x)) { Bail 'Could not unpack the GitHub CLI.' }
  $exe = Get-ChildItem -LiteralPath $x -Filter 'gh.exe' -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
  if (-not $exe) { Bail 'The downloaded archive did not contain the expected program.' }
  Copy-Item -LiteralPath $exe.FullName -Destination (Join-Path $BinDir 'gh.exe') -Force
  Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue

  $userPath = [Environment]::GetEnvironmentVariable('PATH', 'User')
  if (-not $userPath) { $userPath = '' }
  if ($userPath -notlike "*$BinDir*") {
    [Environment]::SetEnvironmentVariable('PATH', ($userPath.TrimEnd(';') + ';' + $BinDir).TrimStart(';'), 'User')
  }
  Sync-Path
  if (-not (Have 'gh')) { Bail 'The GitHub CLI is not on the PATH. Please run the installer again.' }
  Good "Installed v$ver to $BinDir"
}
if (-not (Have 'gh')) { Bail 'The GitHub CLI is not on the PATH. Please run the installer again.' }

# ── 3. Authentication ───────────────────────────────────────
Step '3 / 5   GitHub sign-in'
& gh auth status 2>$null | Out-Null
if ($LASTEXITCODE -eq 0) {
  Good ('Already signed in as ' + (Tool-Version 'gh' @('api', 'user', '--jq', '.login')))
} else {
  Info 'A one-time code will appear below. Copy it, press Enter, and your'
  Info 'browser will open. Paste the code there and approve the request.'
  Write-Host ''
  Start-Sleep -Seconds 1
  & gh auth login --hostname github.com --git-protocol https --web
  if ($LASTEXITCODE -ne 0) { Bail 'Sign-in did not complete. Run the installer again to retry.' }
  Good ('Signed in as ' + (Tool-Version 'gh' @('api', 'user', '--jq', '.login')))
}
& gh auth setup-git 2>$null | Out-Null
if ($LASTEXITCODE -eq 0) { Good 'Git credential helper configured' }

$Me = Tool-Version 'gh' @('api', 'user', '--jq', '.login')
Write-Host ''
Write-Host '  Which account should be synced?' -ForegroundColor White -NoNewline
Write-Host " (Enter for $Me)" -ForegroundColor DarkGray
Write-Host '  > ' -NoNewline
$GhOwner = Read-Host
if ([string]::IsNullOrWhiteSpace($GhOwner)) { $GhOwner = $Me }
$GhOwner = $GhOwner.Trim()
Good "Using $GhOwner"

# ── 4. Location ─────────────────────────────────────────────
Step '4 / 5   Projects folder'
$DefaultDir = Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'GitHub'
Write-Host '  Where should repositories be stored?' -ForegroundColor White -NoNewline
Write-Host " (Enter for $DefaultDir)" -ForegroundColor DarkGray
Write-Host '  > ' -NoNewline
$RepoDir = Read-Host
if ([string]::IsNullOrWhiteSpace($RepoDir)) { $RepoDir = $DefaultDir }
$RepoDir = $RepoDir.Trim().Trim('"')
$RepoDir = [Environment]::ExpandEnvironmentVariables($RepoDir)
if ($RepoDir.StartsWith('~')) {
  $RepoDir = Join-Path $env:USERPROFILE $RepoDir.Substring(1).TrimStart('\', '/')
}
try { New-Item -ItemType Directory -Force -Path $RepoDir -ErrorAction Stop | Out-Null }
catch { Bail "Could not create $RepoDir" }
$RepoDir = (Resolve-Path -LiteralPath $RepoDir).Path
Good "Using $RepoDir"

$confText = "# GitHub Sync for Windows — created $(Get-Date)`r`nREPO_DIR=$RepoDir`r`nGH_OWNER=$GhOwner`r`n"
[System.IO.File]::WriteAllText($Conf, $confText, (New-Object System.Text.UTF8Encoding($false)))
Good 'Settings written to %USERPROFILE%\.githubsync.conf'

$libDest = Join-Path $RepoDir 'lib'
New-Item -ItemType Directory -Force -Path $libDest | Out-Null
foreach ($f in @('common.ps1', 'Pull.ps1', 'Push.ps1', 'CloneNewRepos.ps1')) {
  Copy-Item -LiteralPath (Join-Path $Here "app\lib\$f") -Destination (Join-Path $libDest $f) -Force
}
foreach ($f in @('Pull.cmd', 'Push.cmd', 'Clone New Repos.cmd')) {
  Copy-Item -LiteralPath (Join-Path $Here "app\$f") -Destination (Join-Path $RepoDir $f) -Force
}
Get-ChildItem -LiteralPath $RepoDir -File | Unblock-File -ErrorAction SilentlyContinue
Get-ChildItem -LiteralPath $libDest -File | Unblock-File -ErrorAction SilentlyContinue
Good 'Pull, Push and Clone New Repos placed in the projects folder'

$desktop = [Environment]::GetFolderPath('Desktop')
if ($desktop -and (Test-Path -LiteralPath $desktop)) {
  try {
    $ws = New-Object -ComObject WScript.Shell
    foreach ($n in @('Pull', 'Push')) {
      $lnk = $ws.CreateShortcut((Join-Path $desktop "$n.lnk"))
      $lnk.TargetPath       = (Join-Path $RepoDir "$n.cmd")
      $lnk.WorkingDirectory = $RepoDir
      $lnk.Description      = "GitHub Sync — $n"
      $lnk.Save()
    }
    Good 'Shortcuts added to the Desktop'
  } catch {
    Warn 'Could not create the Desktop shortcuts. The scripts still work from the projects folder.'
  }
}

# ── 5. Clone ────────────────────────────────────────────────
Step '5 / 5   Cloning repositories'
$list  = (& gh repo list $GhOwner --limit 300 --no-archived --json name --jq '.[].name' 2>$null | Out-String)
$names = @($list -split "`r?`n" | ForEach-Object { $_.Trim() } | Where-Object { $_.Length -gt 0 })
if ($names.Count -eq 0) {
  Warn "No repositories found for `"$GhOwner`"."
  Info 'Everything else is configured. Run "Clone New Repos.cmd" later.'
} else {
  $new = 0; $have = 0; $failed = 0
  foreach ($n in $names) {
    if (Test-Path -LiteralPath (Join-Path $RepoDir "$n\.git")) {
      $have++
      Write-Host '    ·  ' -ForegroundColor DarkGray -NoNewline
      Write-Host $n.PadRight(44) -NoNewline
      Write-Host 'already local' -ForegroundColor DarkGray
    } else {
      Write-Host '    ↓  ' -ForegroundColor DarkGray -NoNewline
      Write-Host $n.PadRight(44) -NoNewline
      Push-Location -LiteralPath $RepoDir
      & gh repo clone "$GhOwner/$n" 2>$null | Out-Null
      $rc = $LASTEXITCODE
      Pop-Location
      if ($rc -eq 0) {
        $new++
        Write-Host 'cloned' -ForegroundColor Green
      } else {
        $failed++
        Write-Host 'failed' -ForegroundColor Red
      }
    }
  }
  Write-Host ''
  Good "$new cloned · $have already local · $failed failed"
}

# ── Done ────────────────────────────────────────────────────
Write-Host ''
Rule
Write-Host '  Setup complete' -ForegroundColor White
Rule
Write-Host ''
Write-Host '  Repositories' -ForegroundColor White -NoNewline
Write-Host "   $RepoDir"
Write-Host ''
Write-Host '  Daily use' -ForegroundColor White -NoNewline
Write-Host '      ' -NoNewline
Write-Host 'Pull.cmd' -ForegroundColor White -NoNewline
Write-Host '                 before you start working'
Write-Host '                 ' -NoNewline
Write-Host 'Push.cmd' -ForegroundColor White -NoNewline
Write-Host '                 when you are done'
Write-Host '                 ' -NoNewline
Write-Host 'Clone New Repos.cmd' -ForegroundColor White -NoNewline
Write-Host '      after creating a new repo'
Write-Host ''
Write-Host '  Pull and Push also have shortcuts on the Desktop.' -ForegroundColor DarkGray
Write-Host ''
try { Start-Process -FilePath 'explorer.exe' -ArgumentList "`"$RepoDir`"" } catch { }
Write-Host '  Press Enter to close. ' -ForegroundColor DarkGray -NoNewline
[void](Read-Host)
