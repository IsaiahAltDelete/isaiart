# GitHub Sync for Windows

Keeps every repository on a GitHub account mirrored to a folder on your PC,
driven by three double-clickable scripts instead of the command line.

| Script | What it does |
|---|---|
| `Pull.cmd` | Fast-forwards every local repository from its remote |
| `Push.cmd` | Stages, commits, rebases onto the remote, and pushes every repository |
| `Clone New Repos.cmd` | Clones any repository on the account that isn't local yet |

No global installs, no configuration files to edit by hand, and nothing that
requires an administrator password.

---

## Installation

**Requirements:** Windows 10 or 11, a GitHub account, and an internet
connection. Roughly five minutes, most of it unattended.

1. **Right-click** `WindowsGitHubSync.zip`, choose **Properties**, tick
   **Unblock** at the bottom of the General tab, and click **OK**. Then extract
   the zip.

   > Unblock before extracting. Windows marks everything inside a downloaded
   > zip as untrusted, and that mark is copied to each file as it is extracted.
   > Clearing it once on the zip saves clearing it on every script.

2. Open the extracted folder and double-click `Install.cmd`.

3. If a blue **"Windows protected your PC"** panel appears, click **More info**,
   then **Run anyway**.

   This is SmartScreen reacting to a script it has not seen before, not a virus
   warning. It appears once. If you skipped the Unblock step above it may
   appear for each of the three scripts as well.

4. A console window opens and the installer runs through five steps:

   | Step | What happens |
   |---|---|
   | 1. Git for Windows | Skipped if Git is already installed. Otherwise `winget` installs it into your user folder; if winget is unavailable or refuses, the portable build is downloaded into `%USERPROFILE%\.githubsync\git` instead. Neither route asks for an administrator password. |
   | 2. GitHub CLI | Downloads the official release into `%USERPROFILE%\.githubsync\bin` and adds that folder to your user `PATH`. |
   | 3. GitHub sign-in | Runs `gh auth login` with the browser device flow. Copy the one-time code, approve it in the browser, return to the console. Then confirm which account to sync. |
   | 4. Projects folder | Defaults to `Documents\GitHub`. Press Enter to accept, or type another path. |
   | 5. Cloning | Clones every non-archived repository on the account. |

5. On completion, File Explorer opens the projects folder and `Pull` and `Push`
   have shortcuts on the Desktop.

> **If your Documents folder syncs to OneDrive**, choose somewhere else at
> step 4 — `C:\GitHub`, for instance. A file-sync client and Git both want to
> manage the same files, and they interfere with each other.

The installer is idempotent — re-run it any time to change the account, move
the projects folder, or repair a broken setup.

---

## Daily use

**Pull before you start. Push when you're done.**

### `Pull.cmd`

Runs `git pull --ff-only` in each repository. If local changes block the
fast-forward, it retries with `--rebase --autostash` and notes that it set your
changes aside. Each repository reports `up to date`, `updated (n file(s))`,
`empty repository`, or `failed` with the Git error underneath.

### `Push.cmd`

Prompts for a commit message — press Enter for a computer-and-timestamp
default — then, per repository: `git add -A`, commit,
`git pull --rebase --autostash`, and push. Repositories with nothing to publish
report `no changes` and are skipped. The rebase step exists so a push can't be
rejected for being behind; if it hits a genuine conflict the rebase is aborted
and the repository is reported as `conflict — needs manual merge`, leaving the
working tree intact.

Repositories without an upstream branch are pushed with `-u origin <branch>`.
Repositories with no `origin` remote at all are reported as `skipped` rather
than attempted.

### `Clone New Repos.cmd`

Lists the account's non-archived repositories via `gh repo list` and clones
anything missing. Existing repositories are left untouched. If the GitHub
session has expired it starts the sign-in flow first.

---

## What goes where

| | |
|---|---|
| Repositories | `Documents\GitHub`, or wherever you chose |
| Settings | `%USERPROFILE%\.githubsync.conf` — two lines: `REPO_DIR` and `GH_OWNER` |
| GitHub CLI | `%USERPROFILE%\.githubsync\bin\gh.exe`, unless already installed elsewhere |
| Portable Git (only if winget was unavailable) | `%USERPROFILE%\.githubsync\git` |
| Scripts | `Pull.cmd`, `Push.cmd`, `Clone New Repos.cmd` and a `lib` folder, in the projects folder |
| Logs | `pull.log` and `push.log` in the projects folder |
| Desktop shortcuts | `Pull`, `Push` |

Credentials are handled entirely by `gh auth` and the Git credential helper.
Nothing stores a token in this package.

---

## Troubleshooting

**"Windows protected your PC"**
**More info** → **Run anyway**. Once per file. Unblocking the zip before
extracting avoids it for the three scripts the installer copies.

**The window flashes and closes**
Open the projects folder in Terminal or Command Prompt and run `Pull.cmd` from
there — the error stays on screen. The scripts already run with
`-ExecutionPolicy Bypass`, so a restrictive policy is not the cause.

**Boxes or question marks instead of lines**
The console is using a legacy font. Right-click the title bar → **Properties**
→ **Font** and pick *Consolas* or *Cascadia Mono*. Windows Terminal shows them
correctly by default.

**`git` or `gh` is not recognised**
The user `PATH` changed during install and this window predates it. Close and
reopen it. If it persists, run `Install.cmd` again.

**`failed to push` / `authentication failed`**
The GitHub session expired. Run `Clone New Repos.cmd`, which re-runs
`gh auth login` when it detects a signed-out state, then push again.

**`conflict — needs manual merge`**
The same file diverged locally and remotely. Nothing was lost or committed
over. Resolve that repository by hand, then push again.

**Changing account or folder**
Re-run `Install.cmd`, or edit `%USERPROFILE%\.githubsync.conf` directly.

---

## Uninstalling

Nothing is installed system-wide. Delete the projects folder, the two Desktop
shortcuts, `%USERPROFILE%\.githubsync.conf`, and `%USERPROFILE%\.githubsync`.
Remove `%USERPROFILE%\.githubsync\bin` from your user `PATH` under
**Settings → System → About → Advanced system settings → Environment
Variables**. Run `gh auth logout` to revoke the GitHub session. If Git was
installed by winget, remove it with `winget uninstall Git.Git`.

---

The macOS edition of this tool lives at <https://isaiart.com/macsync/>.
