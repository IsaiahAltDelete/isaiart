#!/bin/bash
# ============================================================
#  GitHub Sync for Mac — installer
# ============================================================
HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$HERE" || exit 1

CONF="$HOME/.githubsync.conf"
TOOLDIR="$HOME/.githubsync"
# The UI kit ships inside this package, so the installer looks the same
# as the scripts it installs.
. "$HERE/app/lib/common.sh"
theme setup

step()  { section "$1"; }
good()  { printf '    %s✔%s  %s
' "$OKC" "$RESET" "$1"; }
info()  { printf '    %s·%s  %s%s%s
' "$FAINT" "$RESET" "$MUTED" "$1" "$RESET"; }
warn()  { printf '    %s▲%s  %s
' "$WARNC" "$RESET" "$1"; }
bail()  { printf '
    %s✖%s  %s

' "$ERRC" "$RESET" "$1"; pause_exit 1; }

clear
banner SETUP "Installer — sets up Git, signs you in, and clones your repositories"
echo
boot "Checking macOS" "Reading this package" "Preparing installer"
echo
box_top "WHAT THIS DOES"
box_row "Runs once, takes about five minutes. You'll sign in to GitHub"
box_row "in your web browser partway through. It installs:"
box_row ""
box_row "${ACC}◆${RESET} Apple Command Line Tools (includes Git), if missing"
box_row "${ACC}◆${RESET} GitHub CLI, into your home folder"
box_row "${ACC}◆${RESET} Pull, Push and Clone New Repos in your projects folder"
box_bot
echo
printf '  %s⏎  press return to begin, or close this window to cancel%s ' "$MUTED" "$RESET"
read -r _

# ── 1. Command Line Tools ───────────────────────────────────
step "1/5  COMMAND LINE TOOLS"
if xcode-select -p >/dev/null 2>&1 && git --version >/dev/null 2>&1; then
  good "Already installed — $(git --version)"
else
  warn "Not installed. A system dialog will open in a moment."
  info "Click \"Install\" in that dialog and wait for it to finish."
  echo
  xcode-select --install >/dev/null 2>&1
  info "Waiting for the installation to complete..."
  tries=0
  until git --version >/dev/null 2>&1; do
    sleep 10; tries=$((tries+1))
    printf '\r    %s%s%s  %sstill waiting (%ss elapsed)%s' "$ACC" "${SPIN[$((tries % 10))]}" "$RESET" "$MUTED" "$((tries*10))" "$RESET"
    [ $tries -gt 90 ] && { echo; bail "Timed out. Once Apple's installer finishes, run this installer again."; }
  done
  echo; good "Installed — $(git --version)"
fi
git --version >/dev/null 2>&1 || bail "Git is still unavailable. Restart the Mac and run this installer again."

# ── 2. GitHub CLI ───────────────────────────────────────────
step "2/5  GITHUB CLI"
if command -v gh >/dev/null 2>&1; then
  good "Already installed — $(gh --version | head -1)"
elif command -v brew >/dev/null 2>&1; then
  info "Installing with Homebrew..."
  brew install gh >/dev/null 2>&1 || bail "Homebrew could not install the GitHub CLI."
  good "Installed — $(gh --version | head -1)"
else
  info "Downloading the official release from github.com..."
  ARCH=$(uname -m); case "$ARCH" in arm64) A=arm64 ;; *) A=amd64 ;; esac
  VER=$(curl -fsSL https://api.github.com/repos/cli/cli/releases/latest \
        | sed -n 's/.*"tag_name" *: *"v\([^"]*\)".*/\1/p' | head -1)
  [ -z "$VER" ] && bail "Could not reach github.com. Check the network connection and try again."
  mkdir -p "$TOOLDIR/tmp" "$TOOLDIR/bin"
  curl -fsSL "https://github.com/cli/cli/releases/download/v${VER}/gh_${VER}_macOS_${A}.zip" \
       -o "$TOOLDIR/tmp/gh.zip" || bail "Download failed. Check the network connection."
  rm -rf "$TOOLDIR/tmp/x"; mkdir -p "$TOOLDIR/tmp/x"
  unzip -qo "$TOOLDIR/tmp/gh.zip" -d "$TOOLDIR/tmp/x" || bail "Could not unpack the GitHub CLI."
  BIN=$(find "$TOOLDIR/tmp/x" -type f -name gh -perm -u+x | head -1)
  [ -z "$BIN" ] && bail "The downloaded archive did not contain the expected binary."
  cp "$BIN" "$TOOLDIR/bin/gh"; chmod +x "$TOOLDIR/bin/gh"
  xattr -dr com.apple.quarantine "$TOOLDIR/bin/gh" 2>/dev/null
  rm -rf "$TOOLDIR/tmp"
  grep -q '.githubsync/bin' "$HOME/.zprofile" 2>/dev/null || \
    echo 'export PATH="$HOME/.githubsync/bin:$PATH"' >> "$HOME/.zprofile"
  good "Installed v$VER to ~/.githubsync/bin"
fi
command -v gh >/dev/null 2>&1 || bail "The GitHub CLI is not on the PATH. Please run the installer again."

# ── 3. Authentication ───────────────────────────────────────
step "3/5  GITHUB SIGN-IN"
if gh auth status >/dev/null 2>&1; then
  good "Already signed in as $(gh api user --jq .login 2>/dev/null)"
else
  info "A one-time code will appear below. Copy it, press Return, and your"
  info "browser will open. Paste the code there and approve the request."
  echo
  sleep 1
  gh auth login --hostname github.com --git-protocol https --web \
    || bail "Sign-in did not complete. Run the installer again to retry."
  good "Signed in as $(gh api user --jq .login 2>/dev/null)"
fi
gh auth setup-git >/dev/null 2>&1 && good "Git credential helper configured"

ME=$(gh api user --jq .login 2>/dev/null)
echo
printf '  %sWhich account should be synced?%s %s(Return for %s)%s\n' "$BOLD" "$RESET" "$MUTED" "$ME" "$RESET"
printf '  %s❯%s ' "$ACC" "$RESET"
read -r GH_OWNER
[ -z "$GH_OWNER" ] && GH_OWNER="$ME"
good "Using $GH_OWNER"

# ── 4. Location ─────────────────────────────────────────────
step "4/5  PROJECTS FOLDER"
DEFAULT_DIR="$HOME/Documents/GitHub"
printf '  %sWhere should repositories be stored?%s %s(Return for %s)%s\n' "$BOLD" "$RESET" "$MUTED" "$DEFAULT_DIR" "$RESET"
printf '  %s❯%s ' "$ACC" "$RESET"
read -r REPO_DIR
[ -z "$REPO_DIR" ] && REPO_DIR="$DEFAULT_DIR"
REPO_DIR="${REPO_DIR/#\~/$HOME}"
mkdir -p "$REPO_DIR" || bail "Could not create $REPO_DIR"
good "Using $REPO_DIR"

cat > "$CONF" <<CONFEOF
# GitHub Sync for Mac — created $(date)
REPO_DIR="$REPO_DIR"
GH_OWNER="$GH_OWNER"
CONFEOF
good "Settings written to ~/.githubsync.conf"

mkdir -p "$REPO_DIR/lib"
cp "$HERE/app/lib/common.sh" "$REPO_DIR/lib/common.sh"
for f in "Pull.command" "Push.command" "Clone New Repos.command"; do
  cp "$HERE/app/$f" "$REPO_DIR/$f"
  chmod +x "$REPO_DIR/$f"
  xattr -dr com.apple.quarantine "$REPO_DIR/$f" 2>/dev/null
done
good "Pull, Push and Clone New Repos placed in the projects folder"

if [ -d "$HOME/Desktop" ]; then
  ln -sf "$REPO_DIR/Pull.command" "$HOME/Desktop/Pull.command" 2>/dev/null
  ln -sf "$REPO_DIR/Push.command" "$HOME/Desktop/Push.command" 2>/dev/null
  good "Aliases added to the Desktop"
fi

# ── 5. Clone ────────────────────────────────────────────────
step "5/5  CLONING REPOSITORIES"
LIST=$(gh repo list "$GH_OWNER" --limit 300 --no-archived --json name --jq '.[].name' 2>/dev/null)
if [ -z "$LIST" ]; then
  warn "No repositories found for \"$GH_OWNER\"."
  info "Everything else is configured. Run Clone New Repos.command later."
else
  new=0; have=0; failed=0
  while IFS= read -r name; do
    [ -z "$name" ] && continue
    if [ -d "$REPO_DIR/$name/.git" ]; then
      have=$((have+1)); printf '    %s·%s  %-44s%salready local%s\n' "$FAINT" "$RESET" "$name" "$MUTED" "$RESET"
    else
      printf '    %s↓%s  %-44s' "$ACC" "$RESET" "$name"
      if (cd "$REPO_DIR" && gh repo clone "$GH_OWNER/$name" >/dev/null 2>&1); then
        new=$((new+1)); printf '%s✔ cloned%s\n' "$OKC" "$RESET"
      else
        failed=$((failed+1)); printf '%s✖ failed%s\n' "$ERRC" "$RESET"
      fi
    fi
  done <<< "$LIST"
  echo
  good "$new cloned · $have already local · $failed failed"
fi

# ── Done ────────────────────────────────────────────────────
echo
box_top "SETUP COMPLETE"
kv "Repositories" "$REPO_DIR"
box_row ""
box_row "${BOLD}Pull.command${RESET}              ${MUTED}before you start working${RESET}"
box_row "${BOLD}Push.command${RESET}              ${MUTED}when you are done${RESET}"
box_row "${BOLD}Clone New Repos.command${RESET}   ${MUTED}after creating a new repo${RESET}"
box_row ""
box_row "${MUTED}Pull and Push are also on your Desktop.${RESET}"
box_bot
open "$REPO_DIR" 2>/dev/null
pause_exit 0
