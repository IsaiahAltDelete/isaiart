# GitHub Sync for Mac

A simple way to keep your GitHub projects on this Mac — **no typing commands required.**

Once it's set up you get three things you double-click:

| Button | What it does |
|---|---|
| **Pull From GitHub** | Downloads the newest version of all your files onto this Mac |
| **Push To GitHub** | Uploads everything you changed, so it goes live |
| **Get New Repos** | Grabs any brand-new projects you've made since last time |

---

## Part 1 — Installing (you only do this once)

### What you need first

- A Mac (any Mac made in the last several years)
- Your **GitHub username and password** — you'll sign in through your web browser
- About 5 minutes and an internet connection

### Step by step

1. **Unzip the file.** Double-click `MacGitHubSync.zip`. A folder called `MacGitHubSync` appears next to it. Drag that folder somewhere you'll remember — the Desktop is perfect.

2. **Open the folder** and find the file called:

   ```
   1 - INSTALL ME.command
   ```

3. **Right-click it** (or hold Control and click) → choose **Open**.

   > ⚠️ **Important:** right-click → Open. If you just double-click it the first time, macOS will refuse to run it.

4. A warning appears saying Apple "cannot verify" the file. Click **Open** (or **Open Anyway**).

   <details>
   <summary>If there's no "Open" button, only "Done" or "Move to Trash"</summary>

   Newer macOS versions hide it. Do this instead:
   1. Open  → **System Settings** → **Privacy & Security**
   2. Scroll down. You'll see a line like *"1 - INSTALL ME.command was blocked…"*
   3. Click **Open Anyway**, then confirm.
   </details>

5. A black **Terminal** window opens with a big purple `SETUP` logo. That's the installer. Press **Return** to begin.

6. Follow along — it walks you through 5 steps:

   - **Step 1 — Developer tools.** If your Mac doesn't have Apple's free developer tools, a small Apple window pops up. Click **Install** and wait (this is the slow part, maybe a few minutes). The installer waits for you.
   - **Step 2 — GitHub helper.** Downloads automatically. Nothing for you to do.
   - **Step 3 — Sign in to GitHub.** A short code appears (like `A1B2-C3D4`). **Copy that code**, press Return, and your browser opens GitHub. Paste the code, click through, and approve. Then switch back to the Terminal window.
   - **Step 4 — Where to keep things.** It suggests `Documents/GitHub`. Just press **Return** to accept it.
   - **Step 5 — Downloading.** It lists each of your projects as it downloads them.

7. When you see the green **ALL DONE!** box, you're finished. A Finder window opens showing your projects, and two shortcuts appear on your Desktop.

You can throw away the `MacGitHubSync` folder now if you like — everything you need is in your projects folder and on the Desktop.

---

## Part 2 — Using it day to day

The golden rule: **Pull before you start. Push when you're finished.**

### Before you work on anything

Double-click **Pull From GitHub**. A cyan `PULL SYNC` screen runs through every project and says `UPDATED` or `ALREADY UP TO DATE`. Press Return to close it.

This makes sure you're editing the newest version of your files.

### After you've made changes

Double-click **Push To GitHub**.

1. It asks you to describe what you changed. Type something short like `fixed the about page` — or just press Return and it'll date-stamp it for you.
2. It goes through each project: `STAGING` → `COMMITTING` → `SYNCING` → `UPLOADING`.
3. Anything you didn't touch says `NOTHING TO UPLOAD (clean)` — that's normal and good.
4. Press Return to close.

Your changes are live on GitHub within a minute or so.

### When you make a brand-new project on GitHub

Double-click **Get New Repos**. It checks your account and downloads anything that isn't on this Mac yet.

---

## Where everything lives

| Thing | Where |
|---|---|
| Your projects | `Documents/GitHub` (or wherever you chose during setup) |
| Desktop shortcuts | `Pull From GitHub` and `Push To GitHub` |
| Your settings | `~/.githubsync.conf` — a plain text file with the folder and account name |
| Records of what happened | `pull_repos.log` and `update_repos.log`, inside your projects folder |

---

## Troubleshooting

**"…cannot be opened because it is from an unidentified developer"**
Right-click the file → **Open** → **Open**. See step 4 above. This only happens the first time for each file.

**Still won't open, no matter what**
Open **Terminal** (Applications → Utilities → Terminal). Type `bash` followed by a space, then **drag the `1 - INSTALL ME.command` file into the Terminal window** and press Return. That always works.

**A project says `UPLOAD FAILED` or `authentication failed`**
Your GitHub sign-in expired. Double-click **Get New Repos** — it'll sign you back in — then try pushing again.

**A project says `CONFLICT — NEEDS A HUMAN`**
The same file got edited in two places at once. Nothing is lost, but it needs sorting out by hand. Make a note of the project name and get someone to untangle it.

**A project says `UPDATE FAILED` when pulling**
Usually the same cause. Try again; if it keeps happening, note the project name.

**The Terminal window closes instantly**
That means the file lost its "runnable" flag. In Terminal, type `chmod +x ` then drag the file in and press Return.

**I want to change the folder or the GitHub account**
Just run `1 - INSTALL ME.command` again — it's safe to re-run any time and won't damage anything you've already downloaded. (Or edit `~/.githubsync.conf` directly.)

---

## Uninstalling

Nothing is installed system-wide. To remove it completely:

- Delete your projects folder (`Documents/GitHub`)
- Delete the two Desktop shortcuts
- Delete `~/.githubsync.conf` and the hidden `~/.githubsync` folder
- If you want to sign out of GitHub: open Terminal and run `gh auth logout`
