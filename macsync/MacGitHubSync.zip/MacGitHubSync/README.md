# GitHub Sync for Mac

Keeps every repository on a GitHub account mirrored to a folder on your Mac,
driven by three double-clickable scripts instead of the command line.

| Script | What it does |
|---|---|
| `Pull.command` | Updates every local repository from GitHub, replaying any local commits on top |
| `Push.command` | Stages, commits, rebases onto the remote, and pushes every repository |
| `Clone New Repos.command` | Clones any repository on the account that isn't local yet |

No global installs, no configuration files to edit by hand, and nothing that
requires an administrator password.

---

## Installation

**Requirements:** macOS, a GitHub account, and an internet connection. Roughly
five minutes, most of it unattended.

1. Unzip `MacGitHubSync.zip` and move the resulting folder somewhere convenient.

2. **Right-click** `Install.command` and choose **Open**.

   > Right-click → Open is required the first time. Double-clicking a script
   > downloaded from the internet is blocked by Gatekeeper.

3. Confirm the "unidentified developer" prompt by clicking **Open**.

   If macOS offers only *Done* or *Move to Trash*, open **System Settings →
   Privacy & Security**, scroll to the message about `Install.command`, and
   click **Open Anyway**.

4. Terminal opens and the installer runs through five steps:

   | Step | What happens |
   |---|---|
   | 1. Command Line Tools | Installs Apple's free developer tools if Git is missing. A system dialog appears — click **Install**. The installer waits for it. |
   | 2. GitHub CLI | Uses Homebrew if present, otherwise downloads the official release into `~/.githubsync/bin`. |
   | 3. GitHub sign-in | Runs `gh auth login` with the browser device flow. Copy the one-time code, approve it in the browser, return to Terminal. Then confirm which account to sync. |
   | 4. Projects folder | Defaults to `~/Documents/GitHub`. Press Return to accept. |
   | 5. Cloning | Clones every non-archived repository on the account. |

5. On completion, Finder opens the projects folder and `Pull` and `Push` are
   aliased to the Desktop.

The installer is idempotent — re-run it any time to change the account, move
the projects folder, or repair a broken setup.

---

## Daily use

**Pull before you start. Push when you're done.**

### `Pull.command`

Runs `git pull --rebase --autostash` in each repository. If this Mac has
commits GitHub doesn't, they are replayed on top of the new remote commits
rather than refused, and uncommitted edits are set aside and restored. Each
repository reports `up to date`, `updated · n files`, `conflict — needs a
manual merge`, or `failed` with the Git error underneath. A conflicted rebase
is always rolled back, so nothing is left half-merged. Branches that have never
been published are skipped.

### `Push.command`

Prompts for a commit message — press Return for a host-and-timestamp default —
then, per repository: `git add -A`, commit, `git pull --rebase --autostash`,
and push. Repositories with nothing to publish report `no changes` and are
skipped. The sync step exists so a push can't be rejected for being behind —
commits from another machine, a cloud agent or a merged pull request are pulled
in first. A genuine conflict rolls the rebase back and is reported as
`conflict — needs a manual merge`; a network or sign-in problem is reported
separately as `couldn't reach GitHub`.

Branches that have never been published skip the sync and are pushed with
`-u origin <branch>`.

### `Clone New Repos.command`

Lists the account's non-archived repositories via `gh repo list` and clones
anything missing. Existing repositories are left untouched.

---

## What goes where

| | |
|---|---|
| Repositories | `~/Documents/GitHub`, or wherever you chose |
| Settings | `~/.githubsync.conf` — two lines: `REPO_DIR` and `GH_OWNER` |
| GitHub CLI (if not via Homebrew) | `~/.githubsync/bin/gh` |
| Logs | `pull.log` and `push.log` in the projects folder |
| Desktop aliases | `Pull.command`, `Push.command` |

Credentials are handled entirely by `gh auth` and the Git credential helper.
Nothing stores a token in this package.

---

## Troubleshooting

**"…cannot be opened because it is from an unidentified developer"**
Right-click → **Open** → **Open**. Once per file. The installer strips the
quarantine attribute from the scripts it copies, so this only affects the
installer itself.

**Nothing opens at all**
In Terminal, type `bash`, a space, then drag the script into the window and
press Return.

**The window closes immediately**
The executable bit was lost. Run `chmod +x` on the script — type `chmod +x`,
a space, drag the file in, press Return.

**`failed to push` / `authentication failed`**
The GitHub session expired. Run `Clone New Repos.command`, which re-runs
`gh auth login` when it detects a signed-out state, then push again.

**`conflict — needs a manual merge`**
The same lines changed locally and on GitHub. The rebase was rolled back, so
nothing was lost or committed over. Resolve that repository by hand, then push
again.

**`couldn't reach GitHub`**
The network dropped or the sign-in expired. Nothing was changed. Check the
connection, run `Clone New Repos.command` to sign in again if needed, and retry.

**`updated, but your uncommitted edits clashed`**
The update succeeded, but your uncommitted edits overlap it. They're safe in
the stash — run `git stash pop` in that repository.

**Changing account or folder**
Re-run `Install.command`, or edit `~/.githubsync.conf` directly.

---

## Uninstalling

Nothing is installed system-wide. Delete the projects folder, the two Desktop
aliases, `~/.githubsync.conf`, and `~/.githubsync`. Run `gh auth logout` to
revoke the GitHub session.
