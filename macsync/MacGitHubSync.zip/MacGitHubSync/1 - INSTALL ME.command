#!/bin/bash
# ============================================================
#  GITHUB SYNC FOR MAC — one-time setup
# ============================================================
HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$HERE" || exit 1

RESET=$'\033[0m'; CYAN=$'\033[96m'; GREEN=$'\033[92m'; YELLOW=$'\033[93m'
RED=$'\033[91m'; MAGENTA=$'\033[95m'; BOLD=$'\033[1m'; DIM=$'\033[2m'
CONF="$HOME/.githubsync.conf"
TOOLDIR="$HOME/.githubsync"
export PATH="$TOOLDIR/bin:/opt/homebrew/bin:/usr/local/bin:$PATH"

say()  { printf '  %s\n' "$1"; }
step() { printf '\n%s  ┌───────────────────────────────────────────────────────────┐%s\n' "$CYAN" "$RESET"
         printf '%s  │%s  %s%-56s%s %s│%s\n' "$CYAN" "$RESET" "$BOLD$YELLOW" "$1" "$RESET" "$CYAN" "$RESET"
         printf '%s  └───────────────────────────────────────────────────────────┘%s\n' "$CYAN" "$RESET"; }
good() { printf '  %s✔%s  %s\n' "$GREEN" "$RESET" "$1"; }
warn() { printf '  %s⚠%s  %s\n' "$YELLOW" "$RESET" "$1"; }
bad()  { printf '  %s✖%s  %s\n' "$RED" "$RESET" "$1"; }
bail() { echo; bad "$1"; echo; printf '  %sPress ENTER to close... %s' "$DIM" "$RESET"; read -r _; exit 1; }

clear
printf '%s%s' "$MAGENTA" "$BOLD"
cat <<'BANNER'

  ███████╗███████╗████████╗██╗   ██╗██████╗
  ██╔════╝██╔════╝╚══██╔══╝██║   ██║██╔══██╗
  ███████╗█████╗     ██║   ██║   ██║██████╔╝
  ╚════██║██╔══╝     ██║   ██║   ██║██╔═══╝
  ███████║███████╗   ██║   ╚██████╔╝██║
  ╚══════╝╚══════╝   ╚═╝    ╚═════╝ ╚═╝

BANNER
printf '%s' "$RESET"
printf '%s  ╔══════════════════════════════════════════════════════════════════════╗\n' "$MAGENTA"
printf '  ║  %s>> GITHUB SYNC FOR MAC — ONE-TIME SETUP <<%s                          ║\n' "$CYAN$MAGENTA" "$MAGENTA"
printf '  ║  %sThis downloads your GitHub projects onto this Mac.%s                   ║\n' "$DIM" "$RESET$MAGENTA"
printf '  ╚══════════════════════════════════════════════════════════════════════╝%s\n' "$RESET"
echo
say "You only have to do this once. It takes about 5 minutes."
say "You will be asked to sign in to GitHub in your web browser."
echo
printf '  %sPress ENTER to begin (or close this window to cancel)...%s ' "$DIM" "$RESET"
read -r _

# ============================================================
step "STEP 1 of 5  —  Developer tools"
# ============================================================
if xcode-select -p >/dev/null 2>&1 && git --version >/dev/null 2>&1; then
  good "Apple developer tools are already installed."
else
  warn "Apple's free developer tools (which include Git) are missing."
  say  "A small Apple window will pop up in a moment."
  say  "${BOLD}Click \"Install\"${RESET} in that window and wait for it to finish."
  echo
  xcode-select --install >/dev/null 2>&1
  say "Waiting for the install to finish..."
  tries=0
  until git --version >/dev/null 2>&1; do
    sleep 10
    tries=$((tries+1))
    printf '  %s… still waiting (%s)%s\n' "$DIM" "$((tries*10))s" "$RESET"
    if [ $tries -gt 90 ]; then
      bail "Timed out. Once Apple's installer finishes, just run this installer again."
    fi
  done
  good "Developer tools installed."
fi
git --version >/dev/null 2>&1 || bail "Git still isn't working. Run this installer again after restarting the Mac."

# ============================================================
step "STEP 2 of 5  —  GitHub helper"
# ============================================================
if command -v gh >/dev/null 2>&1; then
  good "GitHub tool already installed ($(gh --version | head -1))."
elif command -v brew >/dev/null 2>&1; then
  say "Installing via Homebrew, this may take a minute..."
  brew install gh || bail "Homebrew couldn't install the GitHub tool."
  good "GitHub tool installed."
else
  say "Downloading the official GitHub tool from github.com..."
  ARCH=$(uname -m); case "$ARCH" in arm64) A=arm64 ;; *) A=amd64 ;; esac
  VER=$(curl -fsSL https://api.github.com/repos/cli/cli/releases/latest \
        | sed -n 's/.*"tag_name" *: *"v\([^"]*\)".*/\1/p' | head -1)
  [ -z "$VER" ] && bail "Couldn't reach github.com. Check the internet connection and try again."
  mkdir -p "$TOOLDIR/tmp" "$TOOLDIR/bin"
  URL="https://github.com/cli/cli/releases/download/v${VER}/gh_${VER}_macOS_${A}.zip"
  curl -fsSL "$URL" -o "$TOOLDIR/tmp/gh.zip" || bail "Download failed. Check the internet connection."
  rm -rf "$TOOLDIR/tmp/x"; mkdir -p "$TOOLDIR/tmp/x"
  unzip -qo "$TOOLDIR/tmp/gh.zip" -d "$TOOLDIR/tmp/x" || bail "Could not unpack the GitHub tool."
  BIN=$(find "$TOOLDIR/tmp/x" -type f -name gh -perm -u+x | head -1)
  [ -z "$BIN" ] && bail "GitHub tool download looked wrong. Try again later."
  cp "$BIN" "$TOOLDIR/bin/gh"; chmod +x "$TOOLDIR/bin/gh"
  xattr -dr com.apple.quarantine "$TOOLDIR/bin/gh" 2>/dev/null
  rm -rf "$TOOLDIR/tmp"
  grep -q '.githubsync/bin' "$HOME/.zprofile" 2>/dev/null || \
    echo 'export PATH="$HOME/.githubsync/bin:$PATH"' >> "$HOME/.zprofile"
  good "GitHub tool v$VER installed."
fi
command -v gh >/dev/null 2>&1 || bail "The GitHub tool isn't available. Please try the installer again."

# ============================================================
step "STEP 3 of 5  —  Sign in to GitHub"
# ============================================================
if gh auth status >/dev/null 2>&1; then
  good "Already signed in as $(gh api user --jq .login 2>/dev/null)."
else
  say "A code will appear below. Copy it, then your browser will open —"
  say "paste the code there and approve. Come back here when it's done."
  echo
  sleep 2
  gh auth login --hostname github.com --git-protocol https --web || \
    bail "Sign-in didn't complete. Run the installer again to retry."
  good "Signed in."
fi
gh auth setup-git >/dev/null 2>&1 && good "Git can now upload without asking for a password."

ME=$(gh api user --jq .login 2>/dev/null)
echo
printf '  %sWhose GitHub projects should be downloaded?%s\n' "$BOLD$CYAN" "$RESET"
printf '  %s(press ENTER for %s%s%s — the account you just signed into)%s\n' "$DIM" "$RESET$YELLOW" "$ME" "$DIM" "$RESET"
printf '  %s→%s ' "$MAGENTA" "$RESET"
read -r GH_OWNER
[ -z "$GH_OWNER" ] && GH_OWNER="$ME"
good "Using account: $GH_OWNER"

# ============================================================
step "STEP 4 of 5  —  Where to keep the projects"
# ============================================================
DEFAULT_DIR="$HOME/Documents/GitHub"
printf '  %sFolder for your projects%s %s(press ENTER for the usual spot)%s\n' "$BOLD$CYAN" "$RESET" "$DIM" "$RESET"
printf '  %sdefault:%s %s\n' "$DIM" "$RESET" "$DEFAULT_DIR"
printf '  %s→%s ' "$MAGENTA" "$RESET"
read -r REPO_DIR
[ -z "$REPO_DIR" ] && REPO_DIR="$DEFAULT_DIR"
REPO_DIR="${REPO_DIR/#\~/$HOME}"
mkdir -p "$REPO_DIR" || bail "Couldn't create $REPO_DIR"
good "Using folder: $REPO_DIR"

cat > "$CONF" <<CONFEOF
# Created by the GitHub Sync installer on $(date)
REPO_DIR="$REPO_DIR"
GH_OWNER="$GH_OWNER"
CONFEOF
good "Settings saved."

# ── install the double-click buttons ──
mkdir -p "$REPO_DIR/lib"
cp "$HERE/app/lib/common.sh" "$REPO_DIR/lib/common.sh"
for f in "Pull From GitHub.command" "Push To GitHub.command" "Get New Repos.command"; do
  cp "$HERE/app/$f" "$REPO_DIR/$f"
  chmod +x "$REPO_DIR/$f"
  xattr -dr com.apple.quarantine "$REPO_DIR/$f" 2>/dev/null
done
good "Added the Pull / Push / Get-New buttons to that folder."

# ── desktop shortcuts ──
if [ -d "$HOME/Desktop" ]; then
  ln -sf "$REPO_DIR/Pull From GitHub.command" "$HOME/Desktop/Pull From GitHub.command" 2>/dev/null
  ln -sf "$REPO_DIR/Push To GitHub.command"  "$HOME/Desktop/Push To GitHub.command" 2>/dev/null
  good "Put shortcuts on the Desktop too."
fi

# ============================================================
step "STEP 5 of 5  —  Downloading your projects"
# ============================================================
LIST=$(gh repo list "$GH_OWNER" --limit 300 --no-archived --json name --jq '.[].name' 2>/dev/null)
if [ -z "$LIST" ]; then
  warn "No projects found on the account \"$GH_OWNER\"."
  warn "That's fine — everything else is set up. Run \"Get New Repos\" later."
else
  new=0; have=0; failed=0
  while IFS= read -r name; do
    [ -z "$name" ] && continue
    if [ -d "$REPO_DIR/$name/.git" ]; then
      have=$((have+1)); printf '  %s·%s  %-40s %salready here%s\n' "$DIM" "$RESET" "$name" "$DIM" "$RESET"
    else
      printf '  %s↓%s  %-40s' "$CYAN" "$RESET" "$name"
      if (cd "$REPO_DIR" && gh repo clone "$GH_OWNER/$name" >/dev/null 2>&1); then
        new=$((new+1)); printf ' %sdownloaded%s\n' "$GREEN" "$RESET"
      else
        failed=$((failed+1)); printf ' %sfailed%s\n' "$RED" "$RESET"
      fi
    fi
  done <<< "$LIST"
  echo
  good "$new downloaded · $have already present · $failed failed"
fi

# ============================================================
echo
printf '%s  ╔══════════════════════════════════════════════════════════════════════╗%s\n' "$GREEN" "$RESET"
printf '%s  ║%s   %sALL DONE! YOU ARE READY TO GO.%s                                     %s║%s\n' "$GREEN" "$RESET" "$BOLD$GREEN" "$RESET" "$GREEN" "$RESET"
printf '%s  ╚══════════════════════════════════════════════════════════════════════╝%s\n\n' "$GREEN" "$RESET"
say "Your projects live in:"
printf '     %s%s%s\n\n' "$BOLD$YELLOW" "$REPO_DIR" "$RESET"
say "From now on, just double-click:"
printf '     %s• Pull From GitHub%s  — get the newest files before you start working\n' "$CYAN" "$RESET"
printf '     %s• Push To GitHub%s    — publish the changes you made\n' "$MAGENTA" "$RESET"
printf '     %s• Get New Repos%s     — grab any brand-new projects\n\n' "$GREEN" "$RESET"
say "(They're on the Desktop as well as in that folder.)"
echo
open "$REPO_DIR" 2>/dev/null
printf '  %sPress ENTER to close this window... %s' "$DIM" "$RESET"
read -r _
