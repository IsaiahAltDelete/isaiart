#!/bin/bash
# Pull — update every local repository from its remote
cd "$(dirname "$0")" || exit 1
. "$(dirname "$0")/lib/common.sh"

theme pull
load_config
LOGFILE="$REPO_DIR/pull.log"

clear
banner PULL "Update every local repository with the latest changes from GitHub"
echo
boot "Initializing downlink array" "Scanning local repositories" "Handshaking with GitHub"

find_repos
if [ ${#REPOS[@]} -eq 0 ]; then
  no_repos_notice
  log "pull: no repositories in $REPO_DIR"
  pause_exit 1
fi

echo
box_top "SOURCE"
kv "Folder"       "$REPO_DIR"
kv "Account"      "$GH_OWNER"
kv "Repositories" "${#REPOS[@]}"
box_bot
section "UPDATING"

log "── pull started ──"
updated=0; current=0; conflicts=0; failed=0; total=${#REPOS[@]}; idx=0

for repo in "${REPOS[@]}"; do
  idx=$((idx+1))
  name=$(basename "$repo")
  row "$idx" "$total" "$name"

  cd "$repo" || { failed=$((failed+1)); failed_ "folder unreadable"; continue; }
  branch=$(git rev-parse --abbrev-ref HEAD 2>/dev/null)
  if [ -z "$branch" ] || [ "$branch" = "HEAD" ]; then
    failed=$((failed+1)); failed_ "skipped — not on a branch"
    detail "detached HEAD: check out a branch in this repo, then pull again"
    log "SKIP  $name  detached HEAD"; continue
  fi
  if ! has_upstream; then
    current=$((current+1)); neutral "local-only branch ($branch) — nothing to pull"
    log "OK    $name  no upstream for $branch"; continue
  fi

  # Always rebase rather than --ff-only. When this Mac has commits AND
  # GitHub moved on (another machine, a cloud agent, a merged PR),
  # --ff-only refuses and the repo stays stuck until someone fixes it
  # by hand. Rebase replays the local commits on top; --autostash
  # carries uncommitted edits across so they never block the pull.
  before=$(git rev-parse HEAD 2>/dev/null)
  sync_remote; s=$?

  if [ $s -eq 1 ]; then
    conflicts=$((conflicts+1)); warned "conflict — needs a manual merge"
    detail "your commits and GitHub's touch the same lines; rolled back, nothing lost"
    log "CONF  $name  rebase conflict, aborted: $OUT"; continue
  elif [ $s -eq 2 ]; then
    failed=$((failed+1)); failed_ "failed"; detail "$OUT"
    log "FAIL  $name  $OUT"; continue
  fi

  after=$(git rev-parse HEAD 2>/dev/null)
  local_ahead=$(git rev-list --count '@{u}..HEAD' 2>/dev/null || echo 0)
  note=""
  printf '%s' "$OUT" | grep -qi 'created autostash' && note=" · local edits kept"
  [ "${local_ahead:-0}" -gt 0 ] && note="$note · $local_ahead local commit$( [ "$local_ahead" -eq 1 ] || echo s) to push"

  if [ $s -eq 3 ]; then
    updated=$((updated+1)); warned "updated, but your uncommitted edits clashed"
    detail "they are safe in 'git stash' — run 'git stash pop' in this repo to get them back"
    log "WARN  $name  autostash conflict"
  elif [ "$before" = "$after" ] || printf '%s' "$OUT" | grep -qi 'up to date'; then
    current=$((current+1)); neutral "up to date$note"
    log "OK    $name  already up to date"
  else
    updated=$((updated+1))
    changed=$(git diff --name-only "$before" "$after" 2>/dev/null | wc -l | tr -d ' ')
    ok "updated · $changed file$( [ "$changed" = 1 ] || echo s)$note"
    log "OK    $name  updated ($changed files)"
  fi
done

report "updated:$updated:42" "already current:$current:245" "conflicts:$conflicts:214" "failed:$failed:203"

if [ $conflicts -gt 0 ]; then
  printf '\n  %s▲ Conflicted repos were rolled back untouched. Merge them by hand.%s\n' "$WARNC" "$RESET"
fi
if [ $failed -gt 0 ]; then
  printf '\n  %s✖ Some repositories could not be updated. The log has the full Git output.%s\n' "$ERRC" "$RESET"
fi
log "── pull finished: $updated updated, $current current, $conflicts conflicts, $failed failed ──"
pause_exit 0
