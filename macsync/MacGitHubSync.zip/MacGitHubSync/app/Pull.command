#!/bin/bash
# Pull — update every local repository from its remote
cd "$(dirname "$0")" || exit 1
. "$(dirname "$0")/lib/common.sh"

load_config
LOGFILE="$REPO_DIR/pull.log"

clear
heading "GitHub Sync  ·  Pull" "Update every local repository with the latest changes from GitHub"

find_repos
if [ ${#REPOS[@]} -eq 0 ]; then
  no_repos_notice
  log "pull: no repositories in $REPO_DIR"
  pause_exit 1
fi

field "Folder"     "$REPO_DIR"
field "Account"    "$GH_OWNER"
field "Repositories" "${#REPOS[@]}"
section "Updating"

log "── pull started ──"
updated=0; current=0; failed=0; total=${#REPOS[@]}; idx=0

for repo in "${REPOS[@]}"; do
  idx=$((idx+1))
  name=$(basename "$repo")
  row "$idx" "$total" "$name"
  working "working"

  out=$(cd "$repo" && git pull --ff-only 2>&1); rc=$?
  retried=""
  if [ $rc -ne 0 ] && printf '%s' "$out" | grep -qiE 'local changes|would be overwritten|not possible to fast-forward|divergent'; then
    retried=" (local changes set aside)"
    out=$(cd "$repo" && git pull --rebase --autostash 2>&1); rc=$?
  fi

  clear_working
  row "$idx" "$total" "$name"

  if [ $rc -ne 0 ]; then
    failed=$((failed+1))
    failed_ "failed"
    detail "$out"
    log "FAIL  $name  rc=$rc  $out"
  elif printf '%s' "$out" | grep -qi 'already up to date'; then
    current=$((current+1))
    neutral "up to date"
    log "OK    $name  already up to date"
  else
    updated=$((updated+1))
    changed=$(printf '%s' "$out" | grep -cE '^ .*\|' 2>/dev/null)
    if [ "${changed:-0}" -gt 0 ]; then
      ok "updated ($changed file(s))$retried"
    else
      ok "updated$retried"
    fi
    log "OK    $name  updated"
  fi
done

echo
rule
printf '  %sSummary%s     %s%s updated%s   ·   %s%s already current%s   ·   %s%s failed%s\n' \
  "$BOLD" "$RESET" "$GREEN" "$updated" "$RESET" "$DIM" "$current" "$RESET" \
  "$( [ "$failed" -gt 0 ] && printf '%s' "$RED" || printf '%s' "$DIM" )" "$failed" "$RESET"
printf '  %sLog%s         %s%s%s\n' "$BOLD" "$RESET" "$DIM" "$LOGFILE" "$RESET"
rule

if [ "$failed" -gt 0 ]; then
  printf '\n  %sSome repositories could not be updated. See the log for details.%s\n' "$YELLOW" "$RESET"
fi
log "── pull finished: $updated updated, $current current, $failed failed ──"
pause_exit 0
