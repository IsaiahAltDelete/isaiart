#!/bin/bash
# Clone New Repos — download any repositories not present locally
cd "$(dirname "$0")" || exit 1
. "$(dirname "$0")/lib/common.sh"

theme clone
load_config
LOGFILE="$REPO_DIR/pull.log"

clear
banner CLONE "Download any repositories on the account that aren't on this Mac yet"
echo
boot "Locating GitHub CLI" "Verifying sign-in"

if ! command -v gh >/dev/null 2>&1; then
  echo; box_top "MISSING TOOL"
  box_row "${ERRC}The GitHub CLI is not available.${RESET} Run ${BOLD}Install.command${RESET} again."
  box_bot
  pause_exit 1
fi
if ! gh auth status >/dev/null 2>&1; then
  printf '\n  %s▲ You are signed out of GitHub. Starting sign-in...%s\n\n' "$WARNC" "$RESET"
  gh auth login --hostname github.com --git-protocol https --web || pause_exit 1
  echo
fi

LIST=$(gh repo list "$GH_OWNER" --limit 300 --no-archived --json name --jq '.[].name' 2>/dev/null)
if [ -z "$LIST" ]; then
  echo; box_top "NOTHING FOUND"
  box_row "${WARNC}No repositories found for \"$GH_OWNER\".${RESET}"
  box_row "${MUTED}The account name is stored in $CONF${RESET}"
  box_bot
  pause_exit 1
fi
total=$(printf '%s\n' "$LIST" | grep -c .)

echo
box_top "ACCOUNT"
kv "Folder"  "$REPO_DIR"
kv "Account" "$GH_OWNER"
kv "Found"   "$total on GitHub"
box_bot
section "CLONING"

new=0; have=0; failed=0; idx=0
while IFS= read -r name; do
  [ -z "$name" ] && continue
  idx=$((idx+1))
  row "$idx" "$total" "$name"
  if [ -d "$REPO_DIR/$name/.git" ]; then
    have=$((have+1)); neutral "already local"
  else
    cd "$REPO_DIR" || exit 1
    if run "cloning" gh repo clone "$GH_OWNER/$name"; then
      new=$((new+1)); ok "cloned"; log "CLONE $name"
    else
      failed=$((failed+1)); failed_ "failed"; detail "$OUT"; log "FAIL  clone $name: $OUT"
    fi
  fi
done <<< "$LIST"

report "cloned:$new:42" "already local:$have:245" "failed:$failed:203"
pause_exit 0
