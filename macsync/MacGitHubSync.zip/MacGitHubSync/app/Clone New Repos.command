#!/bin/bash
# Clone New Repos — download any repositories not present locally
cd "$(dirname "$0")" || exit 1
. "$(dirname "$0")/lib/common.sh"

load_config
LOGFILE="$REPO_DIR/pull.log"

clear
heading "GitHub Sync  ·  Clone New Repositories" "Download any repositories on the account that aren't on this Mac yet"

if ! command -v gh >/dev/null 2>&1; then
  printf '  %sThe GitHub CLI is not available. Run Install.command again.%s\n' "$RED" "$RESET"
  pause_exit 1
fi
if ! gh auth status >/dev/null 2>&1; then
  printf '  %sYou are signed out of GitHub. Starting sign-in...%s\n\n' "$YELLOW" "$RESET"
  gh auth login --hostname github.com --git-protocol https --web || pause_exit 1
  echo
fi

field "Folder"  "$REPO_DIR"
field "Account" "$GH_OWNER"

LIST=$(gh repo list "$GH_OWNER" --limit 300 --no-archived --json name --jq '.[].name' 2>/dev/null)
if [ -z "$LIST" ]; then
  printf '\n  %sNo repositories found for "%s".%s\n' "$YELLOW" "$GH_OWNER" "$RESET"
  printf '  %sThe account name is stored in %s%s\n' "$DIM" "$CONF" "$RESET"
  pause_exit 1
fi

total=$(printf '%s\n' "$LIST" | grep -c .)
field "Found" "$total on GitHub"
section "Cloning"

new=0; have=0; failed=0; idx=0
while IFS= read -r name; do
  [ -z "$name" ] && continue
  idx=$((idx+1))
  row "$idx" "$total" "$name"
  if [ -d "$REPO_DIR/$name/.git" ]; then
    have=$((have+1)); neutral "already local"
  else
    working "cloning"
    out=$(cd "$REPO_DIR" && gh repo clone "$GH_OWNER/$name" 2>&1); rc=$?
    clear_working; row "$idx" "$total" "$name"
    if [ $rc -eq 0 ]; then
      new=$((new+1)); ok "cloned"; log "CLONE $name"
    else
      failed=$((failed+1)); failed_ "failed"; detail "$out"; log "FAIL  clone $name: $out"
    fi
  fi
done <<< "$LIST"

echo
rule
printf '  %sSummary%s     %s%s cloned%s   ·   %s%s already local%s   ·   %s%s failed%s\n' \
  "$BOLD" "$RESET" "$GREEN" "$new" "$RESET" "$DIM" "$have" "$RESET" \
  "$( [ "$failed" -gt 0 ] && printf '%s' "$RED" || printf '%s' "$DIM" )" "$failed" "$RESET"
printf '  %sFolder%s      %s%s%s\n' "$BOLD" "$RESET" "$DIM" "$REPO_DIR" "$RESET"
rule
pause_exit 0
