#!/bin/bash
# ============================================================
#  common.sh  —  shared bits for the GitHub Sync scripts
# ============================================================

RESET=$'\033[0m'; CYAN=$'\033[96m'; GREEN=$'\033[92m'; YELLOW=$'\033[93m'
RED=$'\033[91m'; MAGENTA=$'\033[95m'; BOLD=$'\033[1m'; DIM=$'\033[2m'

CONF="$HOME/.githubsync.conf"

export PATH="$HOME/.githubsync/bin:/opt/homebrew/bin:/usr/local/bin:$PATH"

c() { printf '%s%s%s' "$1" "$2" "$RESET"; }

divider() { printf '%s' "$CYAN"; printf '  ─%.0s' $(seq 1 37); printf '%s\n' "$RESET"; }

status_line() { # label  value
  printf '  %s[%s %s%-20s%s %s]%s  %s\n' "$DIM$CYAN" "$RESET" "$YELLOW" "$1" "$RESET" "$DIM$CYAN" "$RESET" "$2"
}

boot_sequence() {
  local step
  for step in "$@"; do
    printf '  %s▸%s %s%s%s' "$CYAN" "$RESET" "$DIM" "$step" "$RESET"
    sleep 0.3
    printf '%s  OK%s\n' "$GREEN" "$RESET"
  done
  echo
}

spinner() { # label  name  color
  local frames i f
  frames=('◐' '◓' '◑' '◒')
  for i in 0 1 2 3 4 5 6 7; do
    f=${frames[$((i % 4))]}
    printf '\r  %s%s%s  %s%-11s%s %s%-38.38s%s' "$3" "$f" "$RESET" "$3" "$1" "$RESET" "$DIM" "$2" "$RESET"
    sleep 0.1
  done
  printf '\r%-70s\r' ' '
}

log() { printf '%s - %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$1" >> "$LOGFILE"; }

pause_exit() {
  echo
  printf '  %sPress ENTER to close this window... %s' "$DIM" "$RESET"
  read -r _
  exit "${1:-0}"
}

load_config() {
  if [ ! -f "$CONF" ]; then
    echo
    printf '  %s\n' "$(c "$RED" '╔════════════════════════════════════════════════╗')"
    printf '  %s\n' "$(c "$RED" '║  SETUP NOT FINISHED                            ║')"
    printf '  %s\n' "$(c "$RED" '╚════════════════════════════════════════════════╝')"
    echo
    echo "  Please run the installer first:"
    echo "     1 - INSTALL ME.command"
    pause_exit 1
  fi
  # shellcheck disable=SC1090
  . "$CONF"
  if [ ! -d "$REPO_DIR" ]; then
    echo "  ${RED}Cannot find your websites folder:${RESET} $REPO_DIR"
    echo "  Run the installer again to fix it."
    pause_exit 1
  fi
}

# Fills the global array REPOS with every git repo inside REPO_DIR
find_repos() {
  REPOS=()
  local d
  for d in "$REPO_DIR"/*; do
    [ -d "$d/.git" ] && REPOS+=("$d")
  done
}

print_manifest() { # color
  local col="$1" i=1 r name
  printf '  %s┌─ WEBSITE FOLDERS %s┐%s\n' "$col" "$(printf '─%.0s' $(seq 1 33))" "$RESET"
  for r in "${REPOS[@]}"; do
    name=$(basename "$r")
    printf '  │  %s%02d.%s  %s%s%s\n' "$MAGENTA" "$i" "$RESET" "$YELLOW" "$name" "$RESET"
    i=$((i+1))
  done
  printf '  %s└%s┘%s\n' "$col" "$(printf '─%.0s' $(seq 1 51))" "$RESET"
}

no_repos_banner() {
  printf '\n  %s\n' "$(c "$RED" '╔══════════════════════════════════╗')"
  printf '  %s\n' "$(c "$RED" '║   !!  NO WEBSITES FOUND  !!      ║')"
  printf '  %s\n\n' "$(c "$RED" '╚══════════════════════════════════╝')"
  echo "  Looked in: $REPO_DIR"
  echo "  Try running  'Get New Websites.command'  first."
}
