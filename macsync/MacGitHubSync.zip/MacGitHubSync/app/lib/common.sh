#!/bin/bash
# ============================================================
#  common.sh — shared UI kit and git helpers for GitHub Sync
#
#  Written for the bash macOS ships (3.2): no associative
#  arrays, no ${x,,}, no mapfile, no printf %(...)T.
# ============================================================

GS_VERSION="2.0"
CONF="$HOME/.githubsync.conf"
W=72
export PATH="$HOME/.githubsync/bin:/opt/homebrew/bin:/usr/local/bin:$PATH"

# ── Colour ──────────────────────────────────────────────────
# 256-colour codes: Terminal.app and iTerm both support them,
# and they give the banners a real gradient.
fg()   { printf '\033[38;5;%sm' "$1"; }
RESET=$'\033[0m'; BOLD=$'\033[1m'; DIM=$'\033[2m'
OKC=$(fg 42); WARNC=$(fg 214); ERRC=$(fg 203)
MUTED=$(fg 245); FAINT=$(fg 238); INK=$(fg 255)
# Legacy names, kept for anything still using them.
GREEN=$OKC; RED=$ERRC; YELLOW=$WARNC; BLUE=$(fg 39)

# theme pull|push|clone|setup — picks the banner gradient and accent.
theme() {
  case "$1" in
    pull)  PALETTE="51 45 39 33 27 63";      ACC=$(fg 45)  ;;
    push)  PALETTE="219 213 207 201 165 129"; ACC=$(fg 207) ;;
    clone) PALETTE="157 120 84 48 42 36";    ACC=$(fg 48)  ;;
    *)     PALETTE="229 221 215 209 203 197"; ACC=$(fg 215) ;;
  esac
}
theme setup

# ── Cursor ──────────────────────────────────────────────────
# Hidden while spinners run; always restored, even on Ctrl-C.
cursor_hide() { printf '\033[?25l'; }
cursor_show() { printf '\033[?25h'; }
trap 'cursor_show' EXIT
trap 'cursor_show; printf "\n"; exit 130' INT TERM

# ── Measuring ───────────────────────────────────────────────
# Display width in characters (wc -m honours the UTF-8 locale),
# so box rows line up even with ✔, ·, and ▸ in them.
vlen() { printf '%s' "$1" | LC_ALL=${LC_ALL:-en_US.UTF-8} wc -m | tr -d ' '; }
repeat() { local i=0 s=''; while [ $i -lt "$2" ]; do s="$s$1"; i=$((i+1)); done; printf '%s' "$s"; }
strip() { printf '%s' "$1" | sed $'s/\033\\[[0-9;?]*[A-Za-z]//g'; }

# ── Banners ─────────────────────────────────────────────────
# ANSI Shadow lettering, one gradient step per line.
banner_lines() {
  case "$1" in
PULL) cat <<'EOF'
██████╗ ██╗   ██╗██╗     ██╗
██╔══██╗██║   ██║██║     ██║
██████╔╝██║   ██║██║     ██║
██╔═══╝ ██║   ██║██║     ██║
██║     ╚██████╔╝███████╗███████╗
╚═╝      ╚═════╝ ╚══════╝╚══════╝
EOF
;;
PUSH) cat <<'EOF'
██████╗ ██╗   ██╗███████╗██╗  ██╗
██╔══██╗██║   ██║██╔════╝██║  ██║
██████╔╝██║   ██║███████╗███████║
██╔═══╝ ██║   ██║╚════██║██╔══██║
██║     ╚██████╔╝███████║██║  ██║
╚═╝      ╚═════╝ ╚══════╝╚═╝  ╚═╝
EOF
;;
CLONE) cat <<'EOF'
 ██████╗██╗      ██████╗ ███╗   ██╗███████╗
██╔════╝██║     ██╔═══██╗████╗  ██║██╔════╝
██║     ██║     ██║   ██║██╔██╗ ██║█████╗
██║     ██║     ██║   ██║██║╚██╗██║██╔══╝
╚██████╗███████╗╚██████╔╝██║ ╚████║███████╗
 ╚═════╝╚══════╝ ╚═════╝ ╚═╝  ╚═══╝╚══════╝
EOF
;;
SETUP) cat <<'EOF'
███████╗███████╗████████╗██╗   ██╗██████╗
██╔════╝██╔════╝╚══██╔══╝██║   ██║██╔══██╗
███████╗█████╗     ██║   ██║   ██║██████╔╝
╚════██║██╔══╝     ██║   ██║   ██║██╔═══╝
███████║███████╗   ██║   ╚██████╔╝██║
╚══════╝╚══════╝   ╚═╝    ╚═════╝ ╚═╝
EOF
;;
  esac
}

# banner WORD "subtitle"
banner() {
  local i=0 line c
  set -- "$1" "$2" $PALETTE
  local word="$1" sub="$2"; shift 2
  echo
  banner_lines "$word" | while IFS= read -r line; do
    i=$((i+1)); eval "c=\${$i}"
    printf '  %s%s%s\n' "$(fg "$c")" "$line" "$RESET"
  done
  echo
  local tag="GITHUB SYNC" meta="v$GS_VERSION · macOS"
  local gap=$(( W - 2 - $(vlen "░▒▓ $tag ▓▒░") - $(vlen "$meta") ))
  [ $gap -lt 2 ] && gap=2
  printf '  %s░▒▓%s %s%s%s %s▓▒░%s%s%s%s%s\n' "$ACC" "$RESET" "$BOLD$INK" "$tag" "$RESET" "$ACC" "$RESET" \
    "$(repeat ' ' $gap)" "$MUTED" "$meta" "$RESET"
  [ -n "$sub" ] && printf '  %s%s%s\n' "$MUTED" "$sub" "$RESET"
  printf '  %s%s%s\n' "$FAINT" "$(repeat '━' $((W - 2)))" "$RESET"
}

# ── Boxes ───────────────────────────────────────────────────
box_top() { # [title]
  local t="$1" inner=$((W - 4))
  if [ -n "$t" ]; then
    local fill=$(( inner - $(vlen "$t") - 3 ))
    printf '  %s╭─ %s%s%s %s╮%s\n' "$FAINT" "$ACC$BOLD" "$t" "$RESET$FAINT" "$(repeat '─' $fill)" "$RESET"
  else
    printf '  %s╭%s╮%s\n' "$FAINT" "$(repeat '─' $inner)" "$RESET"
  fi
}
box_row() { # text-with-colour-codes
  local plain; plain=$(strip "$1")
  local pad=$(( W - 6 - $(vlen "$plain") )); [ $pad -lt 0 ] && pad=0
  printf '  %s│%s %s%s %s│%s\n' "$FAINT" "$RESET" "$1" "$(repeat ' ' $pad)" "$FAINT" "$RESET"
}
box_bot() { printf '  %s╰%s╯%s\n' "$FAINT" "$(repeat '─' $((W - 4)))" "$RESET"; }

# fit TEXT MAX — shortens long values to fit a box: home becomes ~,
# and anything still too long loses its middle to an ellipsis.
fit() {
  local s="$1" max="$2" n keep
  case "$s" in "$HOME"*) s="~${s#"$HOME"}" ;; esac
  n=$(vlen "$s")
  if [ "$n" -gt "$max" ]; then
    keep=$(( (max - 1) / 2 ))
    s="${s:0:$keep}…${s:$((n - (max - 1 - keep)))}"
  fi
  printf '%s' "$s"
}

# kv "Label" "value" — a labelled row inside a box.
kv() { box_row "$(printf '%s%-13s%s %s' "$MUTED" "$1" "$RESET" "$(fit "$2" $((W - 21)))")"; }
field() { printf '  %s%-15s%s%s\n' "$MUTED" "$1" "$RESET" "$2"; }

section() { # TITLE
  local fill=$(( W - 8 - $(vlen "$1") ))
  printf '\n  %s┌─[%s %s %s]%s%s\n\n' "$FAINT" "$ACC$BOLD" "$1" "$RESET$FAINT" "$(repeat '─' $fill)" "$RESET"
}
heading() { banner "$1" "$2"; }   # compatibility

# ── Boot sequence ───────────────────────────────────────────
# A few quick status lines. Set GS_FAST=1 to skip the animation.
boot() {
  local msg
  for msg in "$@"; do
    printf '  %s▸%s %s' "$ACC" "$RESET" "$MUTED$msg$RESET"
    local n=$(( 40 - $(vlen "$msg") )) i=0
    [ $n -lt 3 ] && n=3
    while [ $i -lt $n ]; do
      printf '%s.%s' "$FAINT" "$RESET"
      [ -z "$GS_FAST" ] && sleep 0.012
      i=$((i+1))
    done
    printf ' %s[ OK ]%s\n' "$OKC" "$RESET"
  done
}

# ── Repo rows ───────────────────────────────────────────────
# row IDX TOTAL NAME — prints the left half and saves the cursor
# there, so a spinner and then the result can be drawn after it.
row() {
  local idx total name n
  idx=$(printf '%02d' "$1"); total=$(printf '%02d' "$2"); name="$3"
  n=$(( 40 - $(vlen "$name") )); [ $n -lt 2 ] && n=2
  printf '  %s▕%s%s%s/%s%s▏%s %s%s%s %s%s%s ' \
    "$FAINT" "$ACC" "$idx" "$FAINT" "$MUTED$total" "$FAINT" "$RESET" \
    "$BOLD$INK" "$name" "$RESET" "$FAINT" "$(repeat '·' $n)" "$RESET"
  printf '\0337'
}
reset_row() { printf '\0338\033[K'; }

ok()      { reset_row; printf '%s✔ %s%s\n' "$OKC" "$1" "$RESET"; }
neutral() { reset_row; printf '%s· %s%s\n' "$MUTED" "$1" "$RESET"; }
warned()  { reset_row; printf '%s▲ %s%s\n' "$WARNC" "$1" "$RESET"; }
failed_() { reset_row; printf '%s✖ %s%s\n' "$ERRC" "$1" "$RESET"; }
working() { reset_row; printf '%s%s%s' "$MUTED" "$1" "$RESET"; }
clear_working() { reset_row; }

detail() { # up to 3 indented explanation lines
  printf '%s\n' "$1" | grep -v '^[[:space:]]*$' | grep -v '^hint:' | head -3 | while IFS= read -r l; do
    printf '           %s│%s %s%s%s\n' "$FAINT" "$RESET" "$MUTED" "$l" "$RESET"
  done
}

# run LABEL CMD... — runs CMD with a spinner after the current row.
# Leaves output in $OUT and the exit code in $RC.
SPIN=(⠋ ⠙ ⠹ ⠸ ⠼ ⠴ ⠦ ⠧ ⠇ ⠏)
run() {
  local label="$1" tmp pid i=0; shift
  tmp=$(mktemp -t githubsync.XXXXXX)
  ( "$@" ) >"$tmp" 2>&1 &
  pid=$!
  cursor_hide
  while kill -0 "$pid" 2>/dev/null; do
    reset_row
    printf '%s%s%s %s%s%s' "$ACC" "${SPIN[$((i % 10))]}" "$RESET" "$MUTED" "$label" "$RESET"
    i=$((i+1)); sleep 0.08
  done
  wait "$pid"; RC=$?
  OUT=$(cat "$tmp"); rm -f "$tmp"
  cursor_show
  return $RC
}

# ── Summary ─────────────────────────────────────────────────
# report "label:count:colour" ... — a boxed tally with a stacked bar.
report() {
  local item total=0 label count col bar='' seg w=$((W - 10))
  for item in "$@"; do count=${item#*:}; count=${count%%:*}; total=$((total + count)); done
  echo
  box_top "REPORT"
  for item in "$@"; do
    label=${item%%:*}; count=${item#*:}; count=${count%%:*}; col=${item##*:}
    if [ "$total" -gt 0 ]; then seg=$(( (count * w + total / 2) / total )); else seg=0; fi
    [ "$count" -gt 0 ] && [ $seg -eq 0 ] && seg=1
    bar="$bar$(fg "$col")$(repeat '█' $seg)$RESET"
    box_row "$(printf '%s■%s %-16s %s%3s%s' "$(fg "$col")" "$RESET" "$label" "$BOLD$INK" "$count" "$RESET")"
  done
  box_row ""
  box_row "$bar"
  box_row ""
  kv "Time" "$(elapsed)"
  [ -n "$LOGFILE" ] && kv "Log" "$LOGFILE"
  box_bot
}

START_TS=$(date +%s)
elapsed() {
  local s=$(( $(date +%s) - START_TS ))
  if [ $s -ge 60 ]; then printf '%dm %02ds' $((s / 60)) $((s % 60)); else printf '%ds' "$s"; fi
}

log() { [ -n "$LOGFILE" ] && printf '%s  %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$1" >> "$LOGFILE"; }

pause_exit() {
  cursor_show
  echo
  printf '  %s⏎  press return to close%s ' "$MUTED" "$RESET"
  read -r _
  exit "${1:-0}"
}

# ── Config and repos ────────────────────────────────────────
load_config() {
  if [ ! -f "$CONF" ]; then
    echo; box_top "NOT SET UP"
    box_row "Setup has not been run on this Mac yet."
    box_row "Please run ${BOLD}Install.command${RESET} first."
    box_bot
    pause_exit 1
  fi
  # shellcheck disable=SC1090
  . "$CONF"
  if [ ! -d "$REPO_DIR" ]; then
    echo; box_top "FOLDER MISSING"
    box_row "Projects folder not found:"
    box_row "${MUTED}$REPO_DIR${RESET}"
    box_row "Run ${BOLD}Install.command${RESET} again to point it somewhere else."
    box_bot
    pause_exit 1
  fi
}

find_repos() {
  REPOS=()
  local d
  for d in "$REPO_DIR"/*; do
    [ -d "$d/.git" ] && REPOS+=("$d")
  done
}

no_repos_notice() {
  echo; box_top "NO REPOSITORIES"
  box_row "${WARNC}No Git projects were found in this folder.${RESET}"
  kv "Folder" "$REPO_DIR"
  box_row "Run ${BOLD}Clone New Repos.command${RESET} to download them."
  box_bot
}

# ── Git helpers ─────────────────────────────────────────────
# All run inside the current directory (the repo).

has_upstream() { git rev-parse --abbrev-ref --symbolic-full-name '@{u}' >/dev/null 2>&1; }

rebase_in_progress() {
  local g; g=$(git rev-parse --git-dir 2>/dev/null) || return 1
  [ -d "$g/rebase-merge" ] || [ -d "$g/rebase-apply" ]
}

# sync_remote — pull --rebase --autostash, and classify what happened:
#   0 ok · 1 real conflict (rolled back) · 2 other failure (network,
#   auth…) · 3 rebased, but uncommitted edits clashed on re-apply
# The distinction matters: only 1 needs a human to merge anything.
sync_remote() {
  run "syncing with GitHub" git pull --rebase --autostash
  if [ $RC -ne 0 ]; then
    if rebase_in_progress; then
      git rebase --abort >/dev/null 2>&1
      return 1
    fi
    return 2
  fi
  printf '%s' "$OUT" | grep -qi 'autostash resulted in conflicts' && return 3
  return 0
}
