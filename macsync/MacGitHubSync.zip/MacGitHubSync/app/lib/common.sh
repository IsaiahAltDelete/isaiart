#!/bin/bash
# ============================================================
#  common.sh — shared helpers for the GitHub Sync scripts
# ============================================================

RESET=$'\033[0m'; BOLD=$'\033[1m'; DIM=$'\033[2m'
GREEN=$'\033[32m'; RED=$'\033[31m'; YELLOW=$'\033[33m'; BLUE=$'\033[34m'

CONF="$HOME/.githubsync.conf"
WIDTH=68

export PATH="$HOME/.githubsync/bin:/opt/homebrew/bin:/usr/local/bin:$PATH"

rule() { printf '%s' "$DIM"; printf '─%.0s' $(seq 1 $WIDTH); printf '%s\n' "$RESET"; }

heading() { # title  subtitle
  echo
  rule
  printf '  %s%s%s\n' "$BOLD" "$1" "$RESET"
  [ -n "$2" ] && printf '  %s%s%s\n' "$DIM" "$2" "$RESET"
  rule
  echo
}

field() { printf '  %s%-15s%s%s\n' "$DIM" "$1" "$RESET" "$2"; }

section() { printf '\n  %s%s%s\n\n' "$BOLD" "$1" "$RESET"; }

# row  index  total  name   → prints the left-hand part, no newline
row() {
  local tag name pad n
  tag="[$1/$2]"
  name="$3"
  n=$(( 42 - ${#name} ))
  [ $n -lt 2 ] && n=2
  pad=$(printf '%*s' $n '')
  pad=${pad// /.}
  printf '  %s%-7s%s %s %s%s%s ' "$DIM" "$tag" "$RESET" "$name" "$DIM" "$pad" "$RESET"
}

ok()      { printf '%s%s%s\n' "$GREEN" "$1" "$RESET"; }
neutral() { printf '%s%s%s\n' "$DIM" "$1" "$RESET"; }
warned()  { printf '%s%s%s\n' "$YELLOW" "$1" "$RESET"; }
failed_() { printf '%s%s%s\n' "$RED" "$1" "$RESET"; }
working() { printf '%s%s%s' "$DIM" "$1" "$RESET"; }
clear_working() { printf '\r'; }

detail() { # indented dim explanation lines, max 3
  printf '%s' "$1" | head -3 | while IFS= read -r l; do
    [ -n "$l" ] && printf '           %s%s%s\n' "$DIM" "$l" "$RESET"
  done
}

log() { printf '%s  %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$1" >> "$LOGFILE"; }

pause_exit() {
  echo
  printf '  %sPress Return to close this window.%s ' "$DIM" "$RESET"
  read -r _
  exit "${1:-0}"
}

load_config() {
  if [ ! -f "$CONF" ]; then
    heading "Setup has not been run yet" ""
    printf '  Please run %sInstall.command%s first.\n' "$BOLD" "$RESET"
    pause_exit 1
  fi
  # shellcheck disable=SC1090
  . "$CONF"
  if [ ! -d "$REPO_DIR" ]; then
    heading "Projects folder not found" "$REPO_DIR"
    printf '  Run %sInstall.command%s again to point it somewhere else.\n' "$BOLD" "$RESET"
    pause_exit 1
  fi
}

find_repos() {
  REPOS=()
  local d
  for d in "$REPO_DIR"/*; do
    [ -d "$d/.git" ] && REPOS+=("$d")
  done
}

no_repos_notice() {
  printf '  %sNo Git projects were found in this folder.%s\n\n' "$YELLOW" "$RESET"
  field "Folder" "$REPO_DIR"
  printf '\n  Run %sClone New Repos.command%s to download them.\n' "$BOLD" "$RESET"
}
