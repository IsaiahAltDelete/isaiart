#!/bin/bash
# ============================================================
#  GET NEW REPOS — download any repos not on this Mac yet
# ============================================================
cd "$(dirname "$0")" || exit 1
. "$(dirname "$0")/lib/common.sh"

load_config
LOGFILE="$REPO_DIR/pull_repos.log"

clear
printf '%s%s' "$GREEN" "$BOLD"
cat <<'BANNER'

  ███╗   ██╗███████╗██╗    ██╗    ██████╗ ███████╗██████╗  ██████╗ ███████╗
  ████╗  ██║██╔════╝██║    ██║    ██╔══██╗██╔════╝██╔══██╗██╔═══██╗██╔════╝
  ██╔██╗ ██║█████╗  ██║ █╗ ██║    ██████╔╝█████╗  ██████╔╝██║   ██║███████╗
  ██║╚██╗██║██╔══╝  ██║███╗██║    ██╔══██╗██╔══╝  ██╔═══╝ ██║   ██║╚════██║
  ██║ ╚████║███████╗╚███╔███╔╝    ██║  ██║███████╗██║     ╚██████╔╝███████║
  ╚═╝  ╚═══╝╚══════╝ ╚══╝╚══╝     ╚═╝  ╚═╝╚══════╝╚═╝      ╚═════╝ ╚══════╝

BANNER
printf '%s' "$RESET"
printf '%s  ╔══════════════════════════════════════════════════════════════════════╗\n' "$GREEN"
printf '  ║  %s>> LOOKING FOR PROJECTS NOT ON THIS MAC YET <<%s                      ║\n' "$CYAN$GREEN" "$GREEN"
printf '  ╚══════════════════════════════════════════════════════════════════════╝%s\n\n' "$RESET"

if ! command -v gh >/dev/null 2>&1; then
  printf '  %sGitHub tool not found. Please run the installer again.%s\n' "$RED" "$RESET"
  pause_exit 1
fi
if ! gh auth status >/dev/null 2>&1; then
  printf '  %sYou are signed out of GitHub. Signing you back in...%s\n\n' "$YELLOW" "$RESET"
  gh auth login --hostname github.com --git-protocol https --web || pause_exit 1
fi

printf '  %s▸%s %sAsking GitHub what %s owns...%s' "$GREEN" "$RESET" "$DIM" "$GH_OWNER" "$RESET"
ALL=$(gh repo list "$GH_OWNER" --limit 300 --no-archived --json name --jq '.[].name' 2>/dev/null)
if [ -z "$ALL" ]; then
  printf '\n\n  %sNo projects found for account "%s".%s\n' "$RED" "$GH_OWNER" "$RESET"
  printf '  %sCheck the name in %s%s\n' "$DIM" "$CONF" "$RESET"
  pause_exit 1
fi
printf '%s  OK%s\n\n' "$GREEN" "$RESET"

new=0; have=0; failed=0
while IFS= read -r name; do
  [ -z "$name" ] && continue
  if [ -d "$REPO_DIR/$name/.git" ]; then
    have=$((have+1))
    printf '  %s·%s  %-38s %s%s\n' "$DIM" "$RESET" "$name" "$(c "$DIM" 'already here')" "$RESET"
  else
    spinner "CLONING" "$name" "$GREEN"
    out=$(cd "$REPO_DIR" && gh repo clone "$GH_OWNER/$name" 2>&1)
    if [ $? -eq 0 ]; then
      new=$((new+1))
      printf '  %s✔%s  %-38s %s%s\n' "$GREEN" "$RESET" "$name" "$(c "$GREEN" 'DOWNLOADED')" "$RESET"
      log "CLONED $name"
    else
      failed=$((failed+1))
      printf '  %s✖%s  %-38s %s%s\n' "$RED" "$RESET" "$name" "$(c "$RED" 'FAILED')" "$RESET"
      printf '%s' "$out" | head -2 | while IFS= read -r l; do printf '       %s%s%s\n' "$DIM" "$l" "$RESET"; done
      log "CLONE FAILED $name: $out"
    fi
  fi
done <<< "$ALL"

echo
divider
printf '\n  %s◆%s  %s%s new%s downloaded   ·   %s already on this Mac   ·   %s failed\n' \
  "$GREEN" "$RESET" "$BOLD" "$new" "$RESET" "$have" "$failed"
printf '  %sFolder: %s%s\n' "$DIM" "$REPO_DIR" "$RESET"
pause_exit 0
