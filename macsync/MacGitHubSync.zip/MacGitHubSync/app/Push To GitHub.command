#!/bin/bash
# ============================================================
#  PUSH  —  send this Mac's changes up to the live website
# ============================================================
cd "$(dirname "$0")" || exit 1
. "$(dirname "$0")/lib/common.sh"

load_config
LOGFILE="$REPO_DIR/update_repos.log"

clear
printf '%s%s' "$MAGENTA" "$BOLD"
cat <<'BANNER'

  ██████╗ ██╗   ██╗███████╗██╗  ██╗        ███████╗██╗   ██╗███╗   ██╗ ██████╗
  ██╔══██╗██║   ██║██╔════╝██║  ██║        ██╔════╝╚██╗ ██╔╝████╗  ██║██╔════╝
  ██████╔╝██║   ██║███████╗███████║        ███████╗ ╚████╔╝ ██╔██╗ ██║██║
  ██╔═══╝ ██║   ██║╚════██║██╔══██║        ╚════██║  ╚██╔╝  ██║╚██╗██║██║
  ██║     ╚██████╔╝███████║██║  ██║        ███████║   ██║   ██║ ╚████║╚██████╗
  ╚═╝      ╚═════╝ ╚══════╝╚═╝  ╚═╝        ╚══════╝   ╚═╝   ╚═╝  ╚═══╝ ╚═════╝

BANNER
printf '%s' "$RESET"
printf '%s  ╔══════════════════════════════════════════════════════════════════════╗\n' "$MAGENTA"
printf '  ║  %s>> UPLOAD YOUR CHANGES TO GITHUB <<%s                                 ║\n' "$CYAN$MAGENTA" "$MAGENTA"
printf '  ║  %sPublishing everything you edited on this Mac...%s                     ║\n' "$DIM" "$RESET$MAGENTA"
printf '  ╚══════════════════════════════════════════════════════════════════════╝%s\n\n' "$RESET"

# ── What should the change be called? ────────────────────────
default_msg="Updated from Mac — $(date '+%b %d, %Y at %I:%M %p')"
printf '  %sDescribe what you changed%s %s(or just press ENTER)%s\n' "$BOLD$CYAN" "$RESET" "$DIM" "$RESET"
printf '  %s→%s ' "$MAGENTA" "$RESET"
read -r COMMIT_MSG
[ -z "$COMMIT_MSG" ] && COMMIT_MSG="$default_msg"
printf '  %susing:%s %s\n\n' "$DIM" "$RESET" "$COMMIT_MSG"

boot_sequence \
  "Priming uplink transmission array.." \
  "Scanning folders for changes......." \
  "Authenticating push credentials...." \
  "GitHub ready — stand by............"

log "=== PUSH RUN STARTED === msg: $COMMIT_MSG"
find_repos

if [ ${#REPOS[@]} -eq 0 ]; then
  no_repos_banner
  log "No repositories found in $REPO_DIR"
  pause_exit 1
fi

print_manifest "$MAGENTA"
printf '\n  %s◆%s %s%s%s website folders targeted for upload.\n\n' "$GREEN" "$RESET" "$BOLD" "${#REPOS[@]}" "$RESET"
divider

ok=0; failed=0; clean=0; total=${#REPOS[@]}; idx=0

for repo in "${REPOS[@]}"; do
  idx=$((idx+1))
  name=$(basename "$repo")
  printf '\n  %s[%02d/%02d]%s  %s%s%s\n' "$MAGENTA" "$idx" "$total" "$RESET" "$BOLD$YELLOW" "$name" "$RESET"
  log "Processing: $repo"

  cd "$repo" || continue
  branch=$(git rev-parse --abbrev-ref HEAD 2>/dev/null)
  if [ -z "$branch" ] || [ "$branch" = "HEAD" ]; then
    failed=$((failed+1))
    status_line "STATUS" "$(c "$RED" '✖  SKIPPED (odd git state)')"
    log "SKIP $name: no branch"
    continue
  fi

  # ── nothing changed? ──
  if [ -z "$(git status --porcelain)" ] && [ -z "$(git log '@{u}'..HEAD --oneline 2>/dev/null)" ]; then
    clean=$((clean+1))
    status_line "STATUS" "$(c "$DIM$GREEN" '✔  NOTHING TO UPLOAD (clean)')"
    log "CLEAN $name"
    continue
  fi

  # ── stage ──
  spinner "STAGING" "$name" "$YELLOW"
  out=$(git add -A 2>&1) || {
    failed=$((failed+1)); status_line "STAGING" "$(c "$RED" '✖  FAILED')"
    printf '       %s⚠%s  %s%s%s\n' "$RED" "$RESET" "$DIM" "$out" "$RESET"; log "ADD FAILED $name: $out"; continue; }
  status_line "STAGING" "$(c "$GREEN" '✔  OK')"

  # ── commit ──
  spinner "COMMITTING" "$name" "$CYAN"
  if [ -n "$(git status --porcelain)" ]; then
    out=$(git commit -m "$COMMIT_MSG" 2>&1)
    if [ $? -ne 0 ]; then
      failed=$((failed+1)); status_line "COMMITTING" "$(c "$RED" '✖  FAILED')"
      printf '%s' "$out" | head -3 | while IFS= read -r l; do printf '       %s⚠%s  %s%s%s\n' "$RED" "$RESET" "$DIM" "$l" "$RESET"; done
      log "COMMIT FAILED $name: $out"; continue
    fi
    status_line "COMMITTING" "$(c "$GREEN" '✔  OK')"
  else
    status_line "COMMITTING" "$(c "$DIM$GREEN" '✔  NOTHING NEW TO SAVE')"
  fi

  # ── sync down first, so the upload can't be rejected ──
  spinner "SYNCING" "$name" "$YELLOW"
  out=$(git pull --rebase --autostash 2>&1)
  if [ $? -ne 0 ]; then
    failed=$((failed+1))
    status_line "SYNCING" "$(c "$RED" '✖  CONFLICT — NEEDS A HUMAN')"
    printf '%s' "$out" | head -3 | while IFS= read -r l; do printf '       %s⚠%s  %s%s%s\n' "$RED" "$RESET" "$DIM" "$l" "$RESET"; done
    git rebase --abort >/dev/null 2>&1
    log "PULL-REBASE FAILED $name: $out"; continue
  fi
  status_line "SYNCING" "$(c "$GREEN" '✔  OK')"

  # ── push ──
  spinner "UPLOADING" "$name" "$MAGENTA"
  if git rev-parse --abbrev-ref '@{u}' >/dev/null 2>&1; then
    out=$(git push 2>&1)
  else
    out=$(git push -u origin "$branch" 2>&1)
  fi
  if [ $? -ne 0 ]; then
    failed=$((failed+1)); status_line "UPLOADING" "$(c "$RED" '✖  FAILED')"
    printf '%s' "$out" | head -4 | while IFS= read -r l; do printf '       %s⚠%s  %s%s%s\n' "$RED" "$RESET" "$DIM" "$l" "$RESET"; done
    log "PUSH FAILED $name: $out"; continue
  fi
  ok=$((ok+1))
  status_line "UPLOADING" "$(c "$GREEN" '✔  LIVE ON GITHUB')"
  log "PUSHED $name"
done

divider
printf '
  %s╔══════════════════════════════════════════════╗%s
  %s║%s  %sMISSION COMPLETE — UPLOAD REPORT%s             %s║%s
  %s╠══════════════════════════════════════════════╣%s
  %s║%s  %s  ✔  Uploaded  : %-3s folders%s                %s║%s
  %s║%s  %s  ·  No changes: %-3s folders%s                %s║%s
  %s║%s  %s  ✖  Failed    : %-3s folders%s                %s║%s
  %s║%s  %s  ◆  Total     : %-3s folders processed%s      %s║%s
  %s╚══════════════════════════════════════════════╝%s
' "$MAGENTA" "$RESET" "$MAGENTA" "$RESET" "$BOLD$CYAN" "$RESET" "$MAGENTA" "$RESET" \
  "$MAGENTA" "$RESET" \
  "$MAGENTA" "$RESET" "$GREEN" "$ok" "$RESET" "$MAGENTA" "$RESET" \
  "$MAGENTA" "$RESET" "$DIM" "$clean" "$RESET" "$MAGENTA" "$RESET" \
  "$MAGENTA" "$RESET" "$RED" "$failed" "$RESET" "$MAGENTA" "$RESET" \
  "$MAGENTA" "$RESET" "$YELLOW" "$total" "$RESET" "$MAGENTA" "$RESET" \
  "$MAGENTA" "$RESET"

printf '  %sFull log → %s%s\n' "$DIM" "$LOGFILE" "$RESET"
if [ "$ok" -gt 0 ]; then
  printf '\n  %sChanges are usually visible on the live site in about a minute.%s\n' "$DIM" "$RESET"
fi
log "=== PUSH RUN FINISHED: $ok pushed, $clean clean, $failed failed ==="
pause_exit 0
