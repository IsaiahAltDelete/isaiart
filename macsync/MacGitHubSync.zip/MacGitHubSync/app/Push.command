#!/bin/bash
# Push — commit and publish local changes in every repository
cd "$(dirname "$0")" || exit 1
. "$(dirname "$0")/lib/common.sh"

theme push
load_config
LOGFILE="$REPO_DIR/push.log"

clear
banner PUSH "Commit your local changes and publish them to GitHub"
echo
boot "Priming uplink array" "Scanning repositories for changes" "Checking GitHub credentials"

default_msg="Update from $(scutil --get ComputerName 2>/dev/null || echo Mac) — $(date '+%b %d, %Y %H:%M')"
echo
box_top "COMMIT MESSAGE"
box_row "${MUTED}Press Return to use the default:${RESET}"
box_row "$default_msg"
box_bot
printf '  %s❯%s ' "$ACC" "$RESET"
read -r COMMIT_MSG
[ -z "$COMMIT_MSG" ] && COMMIT_MSG="$default_msg"

find_repos
if [ ${#REPOS[@]} -eq 0 ]; then
  no_repos_notice
  log "push: no repositories in $REPO_DIR"
  pause_exit 1
fi

echo
box_top "TARGET"
kv "Folder"       "$REPO_DIR"
kv "Account"      "$GH_OWNER"
kv "Repositories" "${#REPOS[@]}"
box_bot
section "PUBLISHING"

log "── push started ── message: $COMMIT_MSG"
pushed=0; clean=0; conflicts=0; failed=0; total=${#REPOS[@]}; idx=0

for repo in "${REPOS[@]}"; do
  idx=$((idx+1))
  name=$(basename "$repo")
  row "$idx" "$total" "$name"

  cd "$repo" || { failed=$((failed+1)); failed_ "folder unreadable"; continue; }
  branch=$(git rev-parse --abbrev-ref HEAD 2>/dev/null)
  if [ -z "$branch" ] || [ "$branch" = "HEAD" ]; then
    failed=$((failed+1)); failed_ "skipped — not on a branch"
    detail "detached HEAD: check out a branch in this repo, then push again"
    log "SKIP  $name  detached HEAD"; continue
  fi

  # A branch with no upstream has never been published. It can't be
  # pulled, and it always needs pushing — so it skips both the
  # "nothing to do" check and the sync step, and is pushed with -u.
  upstream=1; has_upstream || upstream=0
  dirty=$(git status --porcelain)
  ahead=0
  [ $upstream -eq 1 ] && ahead=$(git rev-list --count '@{u}..HEAD' 2>/dev/null || echo 0)

  if [ -z "$dirty" ] && [ $upstream -eq 1 ] && [ "${ahead:-0}" -eq 0 ]; then
    clean=$((clean+1)); neutral "no changes"
    log "OK    $name  clean"; continue
  fi

  files=0
  if [ -n "$dirty" ]; then
    if ! run "staging" git add -A; then
      failed=$((failed+1)); failed_ "couldn't stage changes"; detail "$OUT"
      log "FAIL  $name  add: $OUT"; continue
    fi
    files=$(git diff --cached --name-only | wc -l | tr -d ' ')
    if [ "$files" -gt 0 ] && ! run "committing" git commit -m "$COMMIT_MSG"; then
      failed=$((failed+1)); failed_ "couldn't commit"; detail "$OUT"
      log "FAIL  $name  commit: $OUT"; continue
    fi
  fi

  # Bring in whatever landed on GitHub since the last pull — another
  # machine, a cloud agent, a merged PR — and replay this commit on top.
  # Without it the push below is rejected as non-fast-forward.
  if [ $upstream -eq 1 ]; then
    sync_remote; s=$?
    if [ $s -eq 1 ]; then
      conflicts=$((conflicts+1)); warned "conflict — needs a manual merge"
      detail "the same lines changed here and on GitHub; nothing was lost, your commit is still local"
      log "CONF  $name  rebase conflict, aborted: $OUT"; continue
    elif [ $s -eq 2 ]; then
      failed=$((failed+1)); failed_ "couldn't reach GitHub"; detail "$OUT"
      log "FAIL  $name  pull: $OUT"; continue
    fi
  fi

  if [ $upstream -eq 1 ]; then
    run "pushing" git push
  else
    run "publishing new branch" git push -u origin "$branch"
  fi

  if [ $RC -ne 0 ]; then
    failed=$((failed+1)); failed_ "push failed"; detail "$OUT"
    log "FAIL  $name  push: $OUT"
  else
    pushed=$((pushed+1))
    msg="pushed"
    [ $upstream -eq 0 ] && msg="published $branch"
    [ "${files:-0}" -gt 0 ] && msg="$msg · $files file$( [ "$files" -eq 1 ] || echo s)"
    ok "$msg"
    log "OK    $name  pushed to $branch"
  fi
done

report "pushed:$pushed:42" "unchanged:$clean:245" "conflicts:$conflicts:214" "failed:$failed:203"

if [ $conflicts -gt 0 ]; then
  printf '\n  %s▲ Conflicted repos were rolled back untouched. Merge them by hand, then push again.%s\n' "$WARNC" "$RESET"
fi
if [ $failed -gt 0 ]; then
  printf '\n  %s✖ Some repositories were not published. The log has the full Git output.%s\n' "$ERRC" "$RESET"
fi
log "── push finished: $pushed pushed, $clean clean, $conflicts conflicts, $failed failed ──"
pause_exit 0
