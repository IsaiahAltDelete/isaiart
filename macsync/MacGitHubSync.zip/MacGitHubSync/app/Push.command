#!/bin/bash
# Push — commit and publish local changes in every repository
cd "$(dirname "$0")" || exit 1
. "$(dirname "$0")/lib/common.sh"

load_config
LOGFILE="$REPO_DIR/push.log"

clear
heading "GitHub Sync  ·  Push" "Commit your local changes and publish them to GitHub"

default_msg="Update from $(scutil --get ComputerName 2>/dev/null || echo Mac) — $(date '+%b %d, %Y %H:%M')"
printf '  %sCommit message%s %s(press Return to use the default)%s\n' "$BOLD" "$RESET" "$DIM" "$RESET"
printf '  %sdefault:%s %s\n' "$DIM" "$RESET" "$default_msg"
printf '  > '
read -r COMMIT_MSG
[ -z "$COMMIT_MSG" ] && COMMIT_MSG="$default_msg"

find_repos
if [ ${#REPOS[@]} -eq 0 ]; then
  echo; no_repos_notice
  log "push: no repositories in $REPO_DIR"
  pause_exit 1
fi

echo
field "Folder"       "$REPO_DIR"
field "Account"      "$GH_OWNER"
field "Repositories" "${#REPOS[@]}"
section "Publishing"

log "── push started ── message: $COMMIT_MSG"
pushed=0; clean=0; failed=0; total=${#REPOS[@]}; idx=0

for repo in "${REPOS[@]}"; do
  idx=$((idx+1))
  name=$(basename "$repo")
  row "$idx" "$total" "$name"

  cd "$repo" || continue
  branch=$(git rev-parse --abbrev-ref HEAD 2>/dev/null)
  if [ -z "$branch" ] || [ "$branch" = "HEAD" ]; then
    failed=$((failed+1)); failed_ "skipped"
    detail "not on a branch (detached HEAD)"
    log "SKIP  $name  detached HEAD"; continue
  fi

  if [ -z "$(git status --porcelain)" ] && [ -z "$(git log '@{u}'..HEAD --oneline 2>/dev/null)" ]; then
    clean=$((clean+1)); neutral "no changes"
    log "OK    $name  clean"; continue
  fi

  working "staging"
  if ! out=$(git add -A 2>&1); then
    clear_working; row "$idx" "$total" "$name"
    failed=$((failed+1)); failed_ "failed to stage"; detail "$out"
    log "FAIL  $name  add: $out"; continue
  fi

  files=$(git diff --cached --name-only | wc -l | tr -d ' ')

  clear_working; row "$idx" "$total" "$name"; working "committing"
  if [ -n "$(git status --porcelain)" ]; then
    if ! out=$(git commit -m "$COMMIT_MSG" 2>&1); then
      clear_working; row "$idx" "$total" "$name"
      failed=$((failed+1)); failed_ "failed to commit"; detail "$out"
      log "FAIL  $name  commit: $out"; continue
    fi
  fi

  clear_working; row "$idx" "$total" "$name"; working "syncing"
  if ! out=$(git pull --rebase --autostash 2>&1); then
    git rebase --abort >/dev/null 2>&1
    clear_working; row "$idx" "$total" "$name"
    failed=$((failed+1)); warned "conflict — needs manual merge"; detail "$out"
    log "FAIL  $name  rebase: $out"; continue
  fi

  clear_working; row "$idx" "$total" "$name"; working "pushing"
  if git rev-parse --abbrev-ref '@{u}' >/dev/null 2>&1; then
    out=$(git push 2>&1); rc=$?
  else
    out=$(git push -u origin "$branch" 2>&1); rc=$?
  fi

  clear_working; row "$idx" "$total" "$name"
  if [ $rc -ne 0 ]; then
    failed=$((failed+1)); failed_ "failed to push"; detail "$out"
    log "FAIL  $name  push: $out"
  else
    pushed=$((pushed+1))
    if [ "${files:-0}" -gt 0 ]; then ok "pushed ($files file(s))"; else ok "pushed"; fi
    log "OK    $name  pushed to $branch"
  fi
done

echo
rule
printf '  %sSummary%s     %s%s pushed%s   ·   %s%s unchanged%s   ·   %s%s failed%s\n' \
  "$BOLD" "$RESET" "$GREEN" "$pushed" "$RESET" "$DIM" "$clean" "$RESET" \
  "$( [ "$failed" -gt 0 ] && printf '%s' "$RED" || printf '%s' "$DIM" )" "$failed" "$RESET"
printf '  %sLog%s         %s%s%s\n' "$BOLD" "$RESET" "$DIM" "$LOGFILE" "$RESET"
rule

if [ "$failed" -gt 0 ]; then
  printf '\n  %sSome repositories were not published. See the log for details.%s\n' "$YELLOW" "$RESET"
fi
log "── push finished: $pushed pushed, $clean clean, $failed failed ──"
pause_exit 0
