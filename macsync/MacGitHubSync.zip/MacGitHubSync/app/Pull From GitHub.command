#!/bin/bash
# ============================================================
#  PULL  —  download the newest version of every website
# ============================================================
cd "$(dirname "$0")" || exit 1
. "$(dirname "$0")/lib/common.sh"

load_config
LOGFILE="$REPO_DIR/pull_repos.log"

clear
printf '%s%s' "$CYAN" "$BOLD"
cat <<'BANNER'

  ██████╗ ██╗   ██╗██╗     ██╗         ███████╗██╗   ██╗███╗   ██╗ ██████╗
  ██╔══██╗██║   ██║██║     ██║         ██╔════╝╚██╗ ██╔╝████╗  ██║██╔════╝
  ██████╔╝██║   ██║██║     ██║         ███████╗ ╚████╔╝ ██╔██╗ ██║██║
  ██╔═══╝ ██║   ██║██║     ██║         ╚════██║  ╚██╔╝  ██║╚██╗██║██║
  ██║     ╚██████╔╝███████╗███████╗    ███████║   ██║   ██║ ╚████║╚██████╗
  ╚═╝      ╚═════╝ ╚══════╝╚══════╝    ╚══════╝   ╚═╝   ╚═╝  ╚═══╝ ╚═════╝

BANNER
printf '%s' "$RESET"
printf '%s  ╔══════════════════════════════════════════════════════════════════════╗\n' "$CYAN"
printf '  ║  %s>> DOWNLOAD LATEST FILES FROM GITHUB <<%s                            ║\n' "$MAGENTA$CYAN" "$CYAN"
printf '  ║  %sBringing this Mac up to date with the website...%s                    ║\n' "$DIM" "$RESET$CYAN"
printf '  ╚══════════════════════════════════════════════════════════════════════╝%s\n\n' "$RESET"

boot_sequence \
  "Initializing uplink array......." \
  "Scanning local folders.........." \
  "Authenticating with GitHub......" \
  "Handshake established..........."

log "=== PULL RUN STARTED ==="
find_repos

if [ ${#REPOS[@]} -eq 0 ]; then
  no_repos_banner
  log "No repositories found in $REPO_DIR"
  pause_exit 1
fi

print_manifest "$CYAN"
printf '\n  %s◆%s %s%s%s website folders found.\n\n' "$GREEN" "$RESET" "$BOLD" "${#REPOS[@]}" "$RESET"
divider

ok=0; failed=0; total=${#REPOS[@]}; idx=0

for repo in "${REPOS[@]}"; do
  idx=$((idx+1))
  name=$(basename "$repo")
  printf '\n  %s[%02d/%02d]%s  %s%s%s\n' "$CYAN" "$idx" "$total" "$RESET" "$BOLD$YELLOW" "$name" "$RESET"
  log "Processing: $repo"

  spinner "PULLING" "$name" "$CYAN"

  out=$(cd "$repo" && git pull --ff-only 2>&1)
  rc=$?

  if [ $rc -ne 0 ]; then
    # Local edits blocking the update? Try stashing them safely.
    if printf '%s' "$out" | grep -qiE 'local changes|would be overwritten|not possible to fast-forward|divergent'; then
      printf '       %s›%s %sLocal edits detected — saving them and retrying...%s\n' "$YELLOW" "$RESET" "$DIM" "$RESET"
      out=$(cd "$repo" && git pull --rebase --autostash 2>&1)
      rc=$?
    fi
  fi

  if [ $rc -ne 0 ]; then
    failed=$((failed+1))
    status_line "STATUS" "$(c "$RED" '✖  UPDATE FAILED')"
    printf '%s' "$out" | head -3 | while IFS= read -r line; do
      printf '       %s⚠%s  %s%s%s\n' "$RED" "$RESET" "$DIM" "$line" "$RESET"
    done
    log "FAILED $name (rc=$rc): $out"
  else
    ok=$((ok+1))
    if printf '%s' "$out" | grep -qi 'already up to date'; then
      status_line "STATUS" "$(c "$DIM$GREEN" '✔  ALREADY UP TO DATE')"
    else
      status_line "STATUS" "$(c "$GREEN" '✔  UPDATED')"
      printf '%s' "$out" | head -4 | while IFS= read -r line; do
        printf '       %s›%s  %s%s%s\n' "$CYAN" "$RESET" "$DIM" "$line" "$RESET"
      done
    fi
    log "OK $name: $out"
  fi
done

divider
printf '
  %s╔══════════════════════════════════════════════╗%s
  %s║%s  %sMISSION COMPLETE — DOWNLOAD REPORT%s           %s║%s
  %s╠══════════════════════════════════════════════╣%s
  %s║%s  %s  ✔  Updated   : %-3s folders%s                %s║%s
  %s║%s  %s  ✖  Failed    : %-3s folders%s                %s║%s
  %s║%s  %s  ◆  Total     : %-3s folders scanned%s        %s║%s
  %s╚══════════════════════════════════════════════╝%s
' "$CYAN" "$RESET" "$CYAN" "$RESET" "$BOLD$MAGENTA" "$RESET" "$CYAN" "$RESET" \
  "$CYAN" "$RESET" \
  "$CYAN" "$RESET" "$GREEN" "$ok" "$RESET" "$CYAN" "$RESET" \
  "$CYAN" "$RESET" "$RED" "$failed" "$RESET" "$CYAN" "$RESET" \
  "$CYAN" "$RESET" "$YELLOW" "$total" "$RESET" "$CYAN" "$RESET" \
  "$CYAN" "$RESET"

printf '  %sFull log → %s%s\n' "$DIM" "$LOGFILE" "$RESET"
log "=== PULL RUN FINISHED: $ok ok, $failed failed ==="
pause_exit 0
